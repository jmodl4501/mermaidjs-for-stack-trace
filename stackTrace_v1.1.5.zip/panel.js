// Mermaid 초기화
mermaid.initialize({
  startOnLoad: true,
  theme: 'default',
  flowchart: {
    useMaxWidth: false,
    htmlLabels: true,
    curve: 'basis'
  }
});

// 페이지 로드 시 디버그 모드 설정
const DEBUG_MODE = true;

// 디버그 로그 함수
function debugLog(...args) {
  if (DEBUG_MODE) {
    console.log('[디버그]', ...args);
  }
}

// 캡처된 에러 저장 객체
const capturedErrors = [];
let isCapturing = false;
let autoSaveCapturedStackTraces = false; // 자동 저장 옵션 추가

// HTML 캔버스를 이미지로 변환하는 유틸리티 함수
function html2canvas(element) {
  return new Promise((resolve, reject) => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      // 요소 크기에 맞게 캔버스 설정
      const rect = element.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
      
      // HTMLElement를 이미지로 변환
      const data = new XMLSerializer().serializeToString(element);
      const DOMURL = window.URL || window.webkitURL || window;
      
      const img = new Image();
      const svgBlob = new Blob([data], {type: 'image/svg+xml;charset=utf-8'});
      const url = DOMURL.createObjectURL(svgBlob);
      
      img.onload = function() {
        ctx.drawImage(img, 0, 0);
        DOMURL.revokeObjectURL(url);
        resolve(canvas);
      };
      
      img.onerror = function() {
        reject(new Error('이미지 로드 실패'));
      };
      
      img.src = url;
    } catch (error) {
      console.error('html2canvas 오류:', error);
      reject(error);
    }
  });
}

/**
 * 다이어그램을 PNG로 저장
 */
function saveDiagramAsPNG(svgData, filename) {
  // 중복 다운로드 방지를 위한 전역 플래그
  if (window.isDownloadInProgress) {
    console.log('다운로드가 이미 진행 중입니다.');
    return;
  }
  
  window.isDownloadInProgress = true;
  console.log('PNG 저장 시작...');
  
  try {
    // 다양한 방법으로 SVG 요소 찾기 시도
    let svgElement = null;
    const activePanel = document.querySelector('.tab-panel.active');
    
    // 1. 현재 활성화된 탭에서 직접 SVG 찾기
    svgElement = activePanel.querySelector('svg');
    
    // 2. 다이어그램 컨테이너에서 SVG 찾기
    if (!svgElement) {
      const mermaidContainer = activePanel.querySelector('#mermaid-container');
      if (mermaidContainer) {
        svgElement = mermaidContainer.querySelector('svg');
      }
    }
    
    // 3. 기타 다양한 컨테이너에서 SVG 찾기
    if (!svgElement) {
      const containers = [
        '#mermaidOutput',
        '.diagram-container',
        '.mermaid'
      ];
      
      for (const selector of containers) {
        const container = activePanel.querySelector(selector);
        if (container) {
          svgElement = container.querySelector('svg');
          if (svgElement) break;
        }
      }
    }
    
    // 4. 문서 전체에서 SVG 찾기 (최후의 수단)
    if (!svgElement) {
      const allSvgs = document.querySelectorAll('svg');
      if (allSvgs.length > 0) {
        // 가장 최근에 생성된 SVG 요소를 선택
        svgElement = allSvgs[allSvgs.length - 1];
      }
    }
    
    // SVG 요소가 없는 경우 처리
    if (!svgElement) {
      console.error('SVG 요소를 찾을 수 없음');
      alert('다이어그램 SVG 요소를 찾을 수 없습니다.');
      window.isDownloadInProgress = false;
      return;
    }

    // SVG를 캡처하기 위한 준비 작업
    const svgRect = svgElement.getBoundingClientRect();
    
    // 원본 SVG 복제 및 조정
    const svgClone = svgElement.cloneNode(true);
    
    // 정확한 크기 설정 - 중요
    svgClone.setAttribute('width', svgRect.width);
    svgClone.setAttribute('height', svgRect.height);
    svgClone.setAttribute('viewBox', `0 0 ${svgRect.width} ${svgRect.height}`);
    svgClone.style.backgroundColor = 'white';
    
    // SVG 인라인 스타일 추가
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      .actor { fill: #f8f9fa; stroke: #999; }
      .messageLine0, .messageLine1 { stroke-width: 2; stroke: #333; }
      .messageText { fill: #333; }
      .loopText, .loopLine { fill: #333; stroke: #999; }
      .note { fill: #ffc; stroke: #999; }
      .noteText { fill: #333; }
      rect, circle, ellipse, polygon, path { stroke-width: 2; }
    `;
    svgClone.appendChild(styleElement);
    
    // SVG XML 생성 및 Base64 인코딩
    const svgXml = new XMLSerializer().serializeToString(svgClone);
    const svg64 = btoa(unescape(encodeURIComponent(svgXml)));
    const imgUrl = `data:image/svg+xml;base64,${svg64}`;
    
    // 이미지 생성 및 로드
    const img = new Image();
    
    img.onload = function() {
      try {
        // 캔버스 생성 및 설정
        const canvas = document.createElement('canvas');
        const scale = 2; // 고해상도
        canvas.width = svgRect.width * scale;
        canvas.height = svgRect.height * scale;
        
        // 캔버스 컨텍스트 설정
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.scale(scale, scale);
        
        // 안티앨리어싱 및 고품질 설정
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        
        // 이미지 그리기
        ctx.drawImage(img, 0, 0);
        
        // PNG로 변환 및 다운로드
        canvas.toBlob(function(blob) {
          // 다운로드가 성공했는지 여부
          let downloadSuccess = false;
          
          try {
            if (blob) {
              const finalFileName = filename || `diagram-${Date.now()}.png`;
              console.log(`다이어그램 저장: ${finalFileName}`);
              
              // Blob URL 생성
              const blobUrl = URL.createObjectURL(blob);
              
              // 다운로드 링크 생성 및 실행
          const link = document.createElement('a');
              link.href = blobUrl;
              link.download = finalFileName;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          
          // 리소스 정리
              setTimeout(() => URL.revokeObjectURL(blobUrl), 200);
              downloadSuccess = true;
              console.log('PNG 저장 성공');
            }
          } catch (downloadError) {
            console.error('다운로드 에러:', downloadError);
          }
          
          // PNG 변환 실패 시 SVG로 저장 (중복 다운로드는 방지)
          if (!downloadSuccess) {
            console.warn('PNG 변환 실패, SVG로 저장 시도');
            saveSVGFallback(imgUrl, filename);
          }
          
          // 다운로드 플래그 초기화
          setTimeout(() => {
            window.isDownloadInProgress = false;
          }, 500);
        }, 'image/png', 1.0);
      } catch (canvasError) {
        console.error('캔버스 처리 오류:', canvasError);
        saveSVGFallback(imgUrl, filename);
        window.isDownloadInProgress = false;
      }
    };
    
    img.onerror = function(imgError) {
      console.error('이미지 로드 오류:', imgError);
      saveSVGFallback(imgUrl, filename);
      window.isDownloadInProgress = false;
    };
    
    // 이미지 로드 시작
    img.src = imgUrl;
    
  } catch (error) {
    console.error('다이어그램 저장 오류:', error);
    alert('다이어그램 저장 중 오류가 발생했습니다: ' + error.message);
    window.isDownloadInProgress = false;
  }
}

// SVG 저장 폴백 함수도 개선
function saveSVGFallback(svgUrl, filename) {
  if (window.isSvgFallbackInProgress) return;
  window.isSvgFallbackInProgress = true;
  
  try {
    alert('PNG 변환이 불가능하여 SVG 형식으로 저장합니다.');
    const finalFileName = (filename || 'diagram.png').replace(/\.png$/, '.svg');
    
    const link = document.createElement('a');
    link.href = svgUrl;
    link.download = finalFileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    console.log('SVG 저장 완료');
  } catch (error) {
    console.error('SVG 저장 폴백 오류:', error);
    alert('SVG 저장 중 오류가 발생했습니다.');
  } finally {
    setTimeout(() => {
      window.isSvgFallbackInProgress = false;
      window.isDownloadInProgress = false;
    }, 500);
  }
}

// 모든 데이터를 한번에 저장하는 함수
function saveAllData() {
  try {
    console.log('모든 데이터 저장 시작');
    const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
    
    // 1. 다이어그램 PNG로 저장
    saveDiagramAsPNG(null, `stack-trace-diagram-${timestamp}.png`);
    
    // 2. 스택 트레이스 저장
    if (window.currentStackTrace) {
      setTimeout(() => {
        saveStackTraceAsText(window.currentStackTrace, `stack-trace-${timestamp}.txt`);
        
        // 3. 소스 코드 저장 (마지막 저장 후 다음 저장 시작)
        if (window.parsedStack) {
          setTimeout(() => {
            const sourceCodeText = generateSourceTextForDownload(window.parsedStack);
            if (sourceCodeText) {
              saveSourceCodeAsText(sourceCodeText, `stack-source-${timestamp}.md`);
            }
          }, 500);
        }
      }, 500);
    }
    
    console.log('모든 데이터 저장 완료');
  } catch (error) {
    console.error('모든 데이터 저장 중 오류:', error);
    alert('데이터 저장 중 오류가 발생했습니다: ' + error.message);
  }
}

// 스택 트레이스를 텍스트 파일로 저장하는 함수
function saveStackTraceAsText(stackTrace, filename) {
  // 텍스트 파일 생성
  const blob = new Blob([stackTrace], {type: 'text/plain'});
  const url = URL.createObjectURL(blob);
  
  // 다운로드 링크 생성
  const link = document.createElement('a');
  link.download = filename || `stack-trace-${new Date().toISOString().slice(0,19).replace(/[T:]/g, '-')}.txt`;
  link.href = url;
  
  // 링크 클릭하여 다운로드
  document.body.appendChild(link);
  link.click();
  
  // 정리
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// 소스 코드를 텍스트 파일로 저장하는 함수
function saveSourceCodeAsText(sourceCode, filename) {
  try {
    // 텍스트 파일 생성
    const blob = new Blob([sourceCode], {type: 'text/plain'});
    const url = URL.createObjectURL(blob);
    
    // 다운로드 링크 생성
    const link = document.createElement('a');
    link.download = filename || `stack-source-${new Date().toISOString().slice(0,19).replace(/[T:]/g, '-')}.txt`;
    link.href = url;
    
    // 링크 클릭하여 다운로드
    document.body.appendChild(link);
    link.click();
    
    // 정리
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('소스 코드 저장 오류:', error);
    alert('소스 코드 파일 저장에 실패했습니다.');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  // 기본 UI 요소들
  const tabManual = document.getElementById('tabManual');
  // 스택 캡처 탭 제거
  // const tabCapture = document.getElementById('tabCapture');
  const tabMermaid = document.getElementById('tabMermaid'); // 새로운 탭
  
  const manualInputPanel = document.getElementById('manualInputPanel');
  // 스택 캡처 패널 제거
  // const capturePanel = document.getElementById('capturePanel');
  const mermaidPanel = document.getElementById('mermaidPanel'); // 새로운 패널
  
  const stackTraceInput = document.getElementById('stackTraceInput');
  const processButton = document.getElementById('processButton');
  const mermaidOutput = document.getElementById('mermaidOutput');
  const sourceCodeOutput = document.getElementById('sourceCodeOutput');
  
  // 스택 캡처 관련 버튼 제거
  // const captureErrorsBtn = document.getElementById('captureErrorsBtn');
  // const stopCaptureBtn = document.getElementById('stopCaptureBtn');
  // const capturedErrorsList = document.getElementById('capturedErrorsList');

  // 다이어그램 작성 관련 요소
  const mermaidEditor = document.getElementById('mermaidEditor');
  const mermaidRenderButton = document.getElementById('mermaidRenderButton');
  const mermaidDiagramOutput = document.getElementById('mermaidDiagramOutput');
  const mermaidTypeSelect = document.getElementById('mermaidTypeSelect');
  const mermaidDirectionSelect = document.getElementById('mermaidDirectionSelect');
  
  // 디버그 정보 표시
  debugLog('패널 초기화 중...');

  // 오류 처리 함수
  function handleError(error, message, element) {
    console.error(`오류 발생: ${message}`, error);
    debugLog(`오류: ${message} - ${error.message || error}`);
    
    // UI에 오류 메시지 표시
    if (element) {
      const errorDiv = document.createElement('div');
      errorDiv.className = 'error-notification';
      errorDiv.textContent = `오류: ${message} - ${error.message || error}`;
      errorDiv.style.cssText = 'background-color: #ffebee; color: #c62828; padding: 8px; margin: 8px 0; border-radius: 4px; border-left: 4px solid #c62828;';
      
      // 자동 제거 타이머 설정
      setTimeout(() => {
        if (errorDiv.parentNode) {
          errorDiv.parentNode.removeChild(errorDiv);
        }
      }, 5000);
      
      // 요소 앞에 오류 메시지 추가
      if (element.parentNode) {
        element.parentNode.insertBefore(errorDiv, element);
      }
    }
  }

  // 요소 존재 확인 함수
  function checkElement(element, name) {
    if (!element) {
      console.error(`요소를 찾을 수 없음: ${name}`);
      debugLog(`요소를 찾을 수 없음: ${name}`);
      return false;
    }
    return true;
  }

  // 탭 전환
  if (checkElement(tabManual, 'tabManual')) {
    tabManual.addEventListener('click', () => {
      try {
        tabManual.classList.add('active');
        // 스택 캡처 탭 제거
        // tabCapture.classList.remove('active');
        tabMermaid.classList.remove('active');
        manualInputPanel.classList.add('active');
        // 스택 캡처 패널 제거
        // capturePanel.classList.remove('active');
        mermaidPanel.classList.remove('active');
        debugLog('수동 입력 탭으로 전환됨');
      } catch (error) {
        handleError(error, '수동 입력 탭 전환 중 오류 발생', tabManual);
      }
    });
  }
  
  // 수동 입력 처리 버튼 이벤트 리스너 수정 - 다이어그램 옵션 적용
  if (checkElement(processButton, 'processButton')) {
    console.log('수동 입력 처리 버튼 이벤트 리스너 등록');
    processButton.addEventListener('click', () => {
      try {
        debugLog('처리 버튼 클릭됨');
        const stackTrace = stackTraceInput.value.trim();
        if (stackTrace) {
          // 다이어그램 종류와 방향 정보 가져오기
          const diagramType = document.getElementById('manualMermaidTypeSelect')?.value || 'flowchart';
          const direction = document.getElementById('manualMermaidDirectionSelect')?.value || 'TD';
          
          // 스타일 옵션을 객체로 전달
          const diagramOptions = {
            type: diagramType,
            direction: direction
          };
          
          // 콜 스택 추적 정보 표시
          processStackTrace(stackTrace, diagramOptions);
          
          // 현재 입력 저장
          window.currentStackTrace = stackTrace;

          // 저장 버튼 텍스트 확인 및 수정
          setTimeout(() => {
            const saveBtn = document.getElementById('saveDiagramBtn');
            if (saveBtn && saveBtn.textContent.includes('SVG')) {
              saveBtn.textContent = 'PNG로 저장';
            }
          }, 200);
          
          debugLog('스택 트레이스 처리 완료');
        } else {
          alert('스택 트레이스를 입력해주세요.');
        }
      } catch (error) {
        handleError(error, '스택 트레이스 처리 중 오류 발생', processButton);
      }
    });
  }

  // 다이어그램 유형 변경 시 방향 선택 표시/숨김 설정 (수동 입력 탭)
  const manualMermaidTypeSelect = document.getElementById('manualMermaidTypeSelect');
  const manualDirectionContainer = document.getElementById('manualDirectionContainer');
  
  if (manualMermaidTypeSelect && manualDirectionContainer) {
    manualMermaidTypeSelect.addEventListener('change', function() {
      const diagramType = this.value;
      
      // 방향 선택 옵션 표시/숨김 처리
      if (diagramType === 'flowchart' || diagramType === 'flowchart-v2') {
        manualDirectionContainer.style.display = 'flex';
                } else {
        manualDirectionContainer.style.display = 'none';
      }
    });
  }

  if (checkElement(tabMermaid, 'tabMermaid')) {
    tabMermaid.addEventListener('click', () => {
      try {
        tabMermaid.classList.add('active');
        tabManual.classList.remove('active');
        // 스택 캡처 탭 제거
        // tabCapture.classList.remove('active');
        mermaidPanel.classList.add('active');
        manualInputPanel.classList.remove('active');
        // 스택 캡처 패널 제거
        // capturePanel.classList.remove('active');
        
        debugLog('다이어그램 편집기 탭으로 전환됨');
      } catch (error) {
        handleError(error, '다이어그램 편집기 탭 전환 중 오류 발생', tabMermaid);
      }
    });
  }

  // 다이어그램 유형 변경 시 샘플 코드 업데이트
  document.addEventListener('change', function(e) {
    if (e.target.id === 'mermaidTypeSelect') {
      const diagramType = e.target.value;
      const direction = document.getElementById('mermaidDirectionSelect')?.value || 'TD';
      
      // 방향 선택 옵션 표시/숨김 처리
      const directionContainer = document.getElementById('directionContainer');
      if (directionContainer) {
        directionContainer.style.display = 
          (diagramType === 'flowchart' || diagramType === 'flowchart-v2') ? 'flex' : 'none';
      }
      
      // 변경 모드인 경우 기존 코드를 유지하고 다이어그램 타입만 변경
      const editMode = document.querySelector('input[name="diagramMode"][value="edit"]')?.checked;
      
      if (editMode && mermaidEditor.value.trim() !== '') {
        // 기존 코드 유지하면서 필요시 타입만 변경 (첫번째 라인)
        const lines = mermaidEditor.value.split('\n');
        if (lines[0].includes('flowchart') || 
            lines[0].includes('sequenceDiagram') || 
            lines[0].includes('classDiagram') || 
            lines[0].includes('stateDiagram')) {
          
          // 다이어그램 타입에 따른 첫 줄 변경
          if (diagramType === 'flowchart') {
            lines[0] = `flowchart ${direction}`;
          } else if (diagramType === 'sequence') {
            lines[0] = 'sequenceDiagram';
          } else if (diagramType === 'class') {
            lines[0] = 'classDiagram';
          } else if (diagramType === 'state') {
            lines[0] = 'stateDiagram-v2';
          } else if (diagramType === 'er') {
            lines[0] = 'erDiagram';
          } else if (diagramType === 'gantt') {
            lines[0] = 'gantt';
          } else if (diagramType === 'pie') {
            lines[0] = 'pie title 제목';
          } else if (diagramType === 'journey') {
            lines[0] = 'journey';
          }
          
          mermaidEditor.value = lines.join('\n');
        }
      }
    }
  });

  // 방향 변경 시 플로우차트인 경우만 샘플 코드 업데이트
  document.addEventListener('change', function(e) {
    if (e.target.id === 'mermaidDirectionSelect') {
      const diagramType = document.getElementById('mermaidTypeSelect')?.value;
      const direction = e.target.value;
      
      // 변경 모드인 경우 기존 코드를 유지하고 방향만 변경
      const editMode = document.querySelector('input[name="diagramMode"][value="edit"]')?.checked;
      
      if (editMode && mermaidEditor.value.trim() !== '' && 
          (diagramType === 'flowchart' || diagramType === 'flowchart-v2')) {
        
        const lines = mermaidEditor.value.split('\n');
        if (lines[0].includes('flowchart')) {
          lines[0] = `flowchart ${direction}`;
          mermaidEditor.value = lines.join('\n');
        }
      }
    }
  });

  // 에디터 내용이 변경됐음을 표시
  mermaidEditor.addEventListener('input', function() {
    this.dataset.edited = 'true';
  });

  // Mermaid 샘플 코드 제공 함수
  function getMermaidSampleCode(type, direction) {
    switch (type) {
      case 'flowchart':
        return `flowchart ${direction}
    A[시작] --> B{조건 확인}
    B -->|예| C[처리 1]
    B -->|아니오| D[처리 2]
    C --> E[종료]
    D --> E`;
      
      case 'sequence':
        return `sequenceDiagram
    사용자->>+서버: 요청
    서버->>+데이터베이스: 쿼리
    데이터베이스-->>-서버: 결과
    서버-->>-사용자: 응답`;
      
      case 'class':
        return `classDiagram
    Animal <|-- Duck
    Animal <|-- Fish
    Animal <|-- Zebra
    Animal : +int age
    Animal : +String gender
    Animal: +isMammal()
    Animal: +mate()
    class Duck{
      +String beakColor
      +swim()
      +quack()
    }
    class Fish{
      -int sizeInFeet
      -canEat()
    }
    class Zebra{
      +bool is_wild
      +run()
    }`;
      
      case 'state':
        return `stateDiagram-v2
    [*] --> 대기
    대기 --> 처리중 : 시작
    처리중 --> 완료 : 성공
    처리중 --> 오류 : 실패
    완료 --> [*]
    오류 --> 대기 : 재시도`;
      
      case 'er':
        return `erDiagram
    CUSTOMER ||--o{ ORDER : places
    ORDER ||--|{ LINE-ITEM : contains
    CUSTOMER }|..|{ DELIVERY-ADDRESS : uses`;
      
      case 'gantt':
        return `gantt
    title 프로젝트 일정
    dateFormat  YYYY-MM-DD
    section 계획
    요구사항 분석       :a1, 2023-01-01, 7d
    설계              :a2, after a1, 5d
    section 개발
    구현              :a3, after a2, 10d
    테스트             :a4, after a3, 5d
    section 배포
    릴리즈             :a5, after a4, 2d`;
      
      case 'pie':
        return `pie title 작업 우선순위
    "중요 & 긴급" : 20
    "중요 & 긴급하지 않음" : 30
    "중요하지 않음 & 긴급" : 10
    "중요하지 않음 & 긴급하지 않음" : 40`;
      
      case 'journey':
        return `journey
    title 사용자 여정 맵
    section 로그인
      홈페이지 방문: 5: 사용자
      로그인 양식 확인: 3: 사용자
      로그인 정보 입력: 4: 사용자
    section 구매
      상품 검색: 5: 사용자
      상품 상세 확인: 3: 사용자
      장바구니 추가: 4: 사용자
      결제 진행: 2: 사용자`;
      
      default:
        return `flowchart ${direction}
    A[시작] --> B{조건 확인}
    B -->|예| C[처리 1]
    B -->|아니오| D[처리 2]
    C --> E[종료]
    D --> E`;
    }
  }

  // 다이어그램 렌더링 버튼 클릭 이벤트
  mermaidRenderButton.addEventListener('click', function() {
    try {
      debugLog('다이어그램 렌더링 버튼 클릭됨');
      renderMermaidDiagram();
    } catch (error) {
      handleError(error, '다이어그램 렌더링 중 오류 발생', mermaidRenderButton);
    }
  });

  // 다이어그램 렌더링 함수
  function renderMermaidDiagram() {
    try {
      const mermaidCode = mermaidEditor.value.trim();
      if (!mermaidCode) {
        alert('다이어그램 코드를 입력해주세요.');
        return;
      }

      mermaidDiagramOutput.innerHTML = '<div class="loading">다이어그램 생성 중...</div>';
      debugLog('Mermaid 다이어그램 렌더링 시작: ' + mermaidCode.substring(0, 30) + '...');
      
      // Mermaid 다이어그램 렌더링
      mermaidDiagramOutput.innerHTML = `<div class="mermaid">${mermaidCode}</div>`;
      
      // 다이어그램 유형 확인
      const isSequenceDiagram = mermaidCode.includes('sequenceDiagram');
      const isClassDiagram = mermaidCode.includes('classDiagram');
      const isStateDiagram = mermaidCode.includes('stateDiagram');
      const isErDiagram = mermaidCode.includes('erDiagram');
      
      // Mermaid 초기화 및 렌더링
      mermaid.initialize({
        startOnLoad: true,
        theme: 'default',
        securityLevel: 'loose',
        flowchart: {
          useMaxWidth: false,
          htmlLabels: true,
          curve: 'basis'
        },
        sequence: {
          useMaxWidth: false,
          width: 200, 
          height: 60, 
          boxMargin: 20,
          boxTextMargin: 16, 
          noteMargin: 20, 
          messageMargin: 60
        },
        classDiagram: {
          useMaxWidth: false,
          diagramPadding: 20,
          htmlLabels: true
        },
        stateDiagram: {
          useMaxWidth: false,
          diagramPadding: 20,
          htmlLabels: true
        },
        er: {
          useMaxWidth: false,
          diagramPadding: 20,
          layoutDirection: 'TB',
          minEntityWidth: 100,
          minEntityHeight: 75
        }
      });
      
      // 다이어그램 렌더링
      mermaid.init(undefined, document.querySelectorAll('.mermaid'));
      debugLog('Mermaid 다이어그램 렌더링 완료');
      
      // SVG 요소 가져오기
      const svgElement = document.querySelector('.mermaid svg');
      if (svgElement) {
        // 기본 SVG 스타일 설정
        svgElement.style.maxWidth = '100%';
        svgElement.style.height = 'auto';
        
        // 다이어그램 유형별 특화 스타일 적용
        if (isSequenceDiagram) {
          // 시퀀스 다이어그램 요소 스타일링
          const actors = svgElement.querySelectorAll('.actor');
          actors.forEach(actor => {
            actor.style.fill = '#f0f0ff';
            actor.style.stroke = '#8080dd';
            actor.style.strokeWidth = '2px';
          });
          
          const messages = svgElement.querySelectorAll('.messageLine0, .messageLine1');
          messages.forEach(message => {
            message.style.stroke = '#3498db';
            message.style.strokeWidth = '2px';
          });
          
          const texts = svgElement.querySelectorAll('text.messageText');
          texts.forEach(text => {
            text.style.fontFamily = '"맑은 고딕", "Malgun Gothic", Arial, sans-serif';
            text.style.fontSize = '14px';
            text.style.fill = '#333';
          });
        } 
        else if (isClassDiagram) {
          // 클래스 다이어그램 스타일링
          const classRects = svgElement.querySelectorAll('.classGroup rect');
          classRects.forEach(rect => {
            rect.style.fill = '#e1f5fe';
            rect.style.stroke = '#4fc3f7';
            rect.style.strokeWidth = '2px';
            rect.setAttribute('rx', '4');
            rect.setAttribute('ry', '4');
          });
          
          const classTexts = svgElement.querySelectorAll('.classGroup text');
          classTexts.forEach(text => {
            text.style.fontFamily = '"맑은 고딕", "Malgun Gothic", Arial, sans-serif';
            text.style.fill = '#333';
          });
          
          const classLabels = svgElement.querySelectorAll('.classLabel');
          classLabels.forEach(label => {
            const foreignObject = label.querySelector('foreignObject');
            if (foreignObject) {
              foreignObject.setAttribute('style', 'overflow: visible;');
            }
          });
          
          // 연결선 스타일링
          const edgePaths = svgElement.querySelectorAll('.relation');
          edgePaths.forEach(path => {
            path.style.stroke = '#3498db';
            path.style.strokeWidth = '2px';
          });
        }
        else if (isStateDiagram) {
          // 상태 다이어그램 스타일링
          const stateNodes = svgElement.querySelectorAll('.stateGroup rect');
          stateNodes.forEach(rect => {
            rect.style.fill = '#e8f5e9';
            rect.style.stroke = '#66bb6a';
            rect.style.strokeWidth = '2px';
            rect.setAttribute('rx', '8');
            rect.setAttribute('ry', '8');
          });
          
          const stateTexts = svgElement.querySelectorAll('.stateGroup text, .stateLabel text');
          stateTexts.forEach(text => {
            text.style.fontFamily = '"맑은 고딕", "Malgun Gothic", Arial, sans-serif';
            text.style.fill = '#333';
          });
          
          // 연결선 스타일링
          const transitions = svgElement.querySelectorAll('.transition');
          transitions.forEach(path => {
            path.style.stroke = '#43a047';
            path.style.strokeWidth = '2px';
          });
          
          // 시작/종료 상태 스타일링
          const startStates = svgElement.querySelectorAll('circle.start-state');
          startStates.forEach(circle => {
            circle.style.fill = '#66bb6a';
            circle.style.stroke = '#2e7d32';
            circle.style.strokeWidth = '2px';
          });
        }
        else if (isErDiagram) {
          // ER 다이어그램 스타일링
          const entities = svgElement.querySelectorAll('.entityBox');
          entities.forEach(rect => {
            rect.style.fill = '#fff8e1';
            rect.style.stroke = '#ffca28';
            rect.style.strokeWidth = '2px';
            rect.setAttribute('rx', '5');
            rect.setAttribute('ry', '5');
          });
          
          const entityTexts = svgElement.querySelectorAll('.entityLabel text');
          entityTexts.forEach(text => {
            text.style.fontFamily = '"맑은 고딕", "Malgun Gothic", Arial, sans-serif';
            text.style.fill = '#333';
            text.style.fontWeight = 'bold';
          });
          
          // 관계 스타일링
          const relations = svgElement.querySelectorAll('.relationshipLabelBox');
          relations.forEach(rect => {
            rect.style.fill = '#fff';
            rect.style.stroke = '#ffb300';
            rect.style.strokeWidth = '1px';
          });
          
          const relationTexts = svgElement.querySelectorAll('.relationshipLabel text');
          relationTexts.forEach(text => {
            text.style.fontFamily = '"맑은 고딕", "Malgun Gothic", Arial, sans-serif';
            text.style.fill = '#bf360c';
          });
          
          // 연결선 스타일링
          const edgePaths = svgElement.querySelectorAll('.er path');
          edgePaths.forEach(path => {
            path.style.stroke = '#ffa000';
            path.style.strokeWidth = '2px';
          });
        }
        else {
          // 기본 플로우차트 스타일링
          const nodes = svgElement.querySelectorAll('.node rect, .node circle, .node ellipse, .node polygon, .node path');
          nodes.forEach(node => {
            node.style.fill = '#f0f0ff';
            node.style.stroke = '#8080dd';
            node.style.strokeWidth = '2px';
            if (node.tagName.toLowerCase() === 'rect') {
              node.setAttribute('rx', '5');
              node.setAttribute('ry', '5');
            }
          });
          
          const nodeTexts = svgElement.querySelectorAll('.node text');
          nodeTexts.forEach(text => {
            text.style.fontFamily = '"맑은 고딕", "Malgun Gothic", Arial, sans-serif';
            text.style.fill = '#333';
          });
          
          const edgePaths = svgElement.querySelectorAll('.edgePath path');
          edgePaths.forEach(path => {
            path.style.stroke = '#3498db';
            path.style.strokeWidth = '2px';
          });
        }
      }
      
      // 저장 버튼 추가
      const buttonsContainer = document.createElement('div');
      buttonsContainer.className = 'diagram-buttons';
      buttonsContainer.innerHTML = `
        <button id="saveDiagramButton" class="action-btn">PNG로 저장</button>
        <button id="copyMermaidCodeButton" class="action-btn">코드 복사</button>
      `;
      
      // 이전 버튼 컨테이너 제거
      const existingButtons = mermaidDiagramOutput.querySelector('.diagram-buttons');
      if (existingButtons) {
        existingButtons.remove();
      }
      
      mermaidDiagramOutput.appendChild(buttonsContainer);
      
      // 버튼 이벤트 리스너 추가
      const saveDiagramButton = document.getElementById('saveDiagramButton');
      if (checkElement(saveDiagramButton, 'saveDiagramButton')) {
        saveDiagramButton.addEventListener('click', function() {
          try {
            debugLog('PNG 저장 버튼 클릭됨');
            const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
            saveDiagramAsPNG(null, `mermaid-diagram-${timestamp}.png`);
          } catch (error) {
            handleError(error, '다이어그램 저장 중 오류 발생', this);
          }
        });
      }
      
      const copyMermaidCodeButton = document.getElementById('copyMermaidCodeButton');
      if (checkElement(copyMermaidCodeButton, 'copyMermaidCodeButton')) {
        copyMermaidCodeButton.addEventListener('click', function() {
          try {
            debugLog('코드 복사 버튼 클릭됨');
            navigator.clipboard.writeText(mermaidCode)
              .then(() => {
                this.textContent = '복사됨!';
                setTimeout(() => {
                  this.textContent = '코드 복사';
                }, 2000);
              })
              .catch(err => {
                console.error('클립보드 복사 실패:', err);
                handleError(err, '코드 복사 실패', this);
                alert('코드 복사에 실패했습니다.');
              });
          } catch (error) {
            handleError(error, '코드 복사 중 오류 발생', this);
          }
        });
      }
    } catch (error) {
      console.error('Mermaid 다이어그램 렌더링 오류:', error);
      handleError(error, 'Mermaid 다이어그램 렌더링 오류', mermaidDiagramOutput);
      mermaidDiagramOutput.innerHTML = `
        <div class="error-message">
          <h3>다이어그램 렌더링 실패</h3>
          <p>${error.message}</p>
          <pre>${error.stack || ''}</pre>
          <p>문법을 확인하고 다시 시도해주세요.</p>
        </div>
      `;
    }
  }

  // 스택 트레이스 처리 공통 함수 - 다이어그램 옵션 파라미터 추가
  function processStackTrace(stackTrace, diagramOptions = {}) {
    try {
      console.log('처리할 스택 트레이스:', stackTrace);
      debugLog('스택 트레이스 처리 시작');

      // 스택 트레이스 파싱
      const parsedStack = parseStackTrace(stackTrace);
      console.log('파싱된 스택:', parsedStack);
      
      // 다이어그램 생성 - 옵션 전달
      generateMermaidDiagram(parsedStack, diagramOptions);
      
      // 소스 코드 섹션 생성
      generateSourceCode(parsedStack);
      
      // 현재 처리 중인 스택 트레이스 저장 (저장 버튼용)
      window.currentStackTrace = stackTrace;
      window.parsedStack = parsedStack;
      
      debugLog('스택 트레이스 처리 완료');
    } catch (error) {
      handleError(error, '스택 트레이스 처리 중 오류 발생', mermaidOutput);
      console.error('스택 트레이스 처리 실패:', error);
      
      // UI에 오류 메시지 표시
      mermaidOutput.innerHTML = `
        <div class="error-message">
          <h3>스택 트레이스 처리 실패</h3>
          <p>${error.message || '알 수 없는 오류가 발생했습니다.'}</p>
          <pre>${error.stack || ''}</pre>
        </div>
      `;
    }
  }

  /**
   * 스택 트레이스를 파싱하여 구조화된 데이터로 변환
   */
  function parseStackTrace(stackTrace) {
    const lines = stackTrace.split('\n');
    const parsedStack = [];
    
    // 첫 번째 줄은 일반적으로 에러 메시지이므로 스킵할 수 있음
    const errorMessageLine = lines[0];
    let errorMessage = '';
    
    if (!errorMessageLine.trim().startsWith('at ') && !errorMessageLine.includes('@')) {
      errorMessage = errorMessageLine.trim();
    }

    // 파일명에서 쿼리 파라미터 제거 함수
    function cleanFileName(fileName) {
      if (!fileName) return '';
      // ? 이후의 쿼리스트링 제거
      return fileName.split('?')[0];
    }

    // 각 스택 프레임 파싱
    for (const line of lines) {
      const trimmedLine = line.trim();
      
      // 정규식 패턴 - 크롬 스타일 ('at 함수명 (파일:라인:컬럼)') 또는 넥사크로 스타일 ('함수명 @ 파일:라인:컬럼')
      // 크롬 표준 스택 트레이스 스타일
      let match = null;
      let functionName = '';
      let filePath = '';
      let lineNumber = 0;
      let columnNumber = 0;
      
      // 크롬 스타일: 'at 함수명 (파일:라인:컬럼)'
      if (trimmedLine.startsWith('at ')) {
        const regex = /at\s+(?:(.+?)\s+\()?(?:(.+?):(\d+):(\d+))\)?/;
        match = trimmedLine.match(regex);
        
        if (match) {
          [_, functionName, filePath, lineNumber, columnNumber] = match;
        }
      } 
      // 넥사크로 스타일: '함수명 @ 파일:라인'
      else if (trimmedLine.includes('@')) {
        const parts = trimmedLine.split('@');
        functionName = parts[0].trim();
        
        const urlMatch = parts[1].trim().match(/(.+):(\d+)(?::(\d+))?/);
        if (urlMatch) {
          filePath = urlMatch[1];
          lineNumber = urlMatch[2];
          columnNumber = urlMatch[3] || 0;
          match = [null, functionName, filePath, lineNumber, columnNumber];
        }
      }
      
      if (match) {
        // 파일 경로에서 파일명만 추출 (경로 제외)
        const fullPath = filePath;
        const fileName = fullPath.split('/').pop();
        const cleanedFileName = cleanFileName(fileName);
        
        parsedStack.push({
          functionName: functionName || '(anonymous)',
          filePath: fullPath,
          fileName: cleanedFileName,
          origFileName: fileName, // 원본 파일명도 저장
          lineNumber: parseInt(lineNumber, 10),
          columnNumber: parseInt(columnNumber, 10) || 0,
          raw: trimmedLine
        });
      }
    }
    
    return {
      errorMessage,
      frames: parsedStack
    };
  }

  /**
   * Mermaid 다이어그램 생성 - 다이어그램 옵션 파라미터 추가
   */
  function generateMermaidDiagram(parsedStack, diagramOptions = {}) {
    const { frames } = parsedStack;
    
    if (frames.length === 0) {
      mermaidOutput.innerHTML = '<p>파싱할 스택 프레임이 없습니다.</p>';
      return;
    }
    
    // 표시 옵션 추가 (full, file, function 중 하나)
    // displayOption 변수 정의 추가 - 기본값은 'full'
    const displayOption = 'full';
    
    // 다이어그램 옵션 설정
    const diagramType = diagramOptions.type || 'flowchart';
    const direction = diagramOptions.direction || 'TD';
    
    // 설정 객체
    const settings = {
      ignoreList: [], // 기본 무시 목록
      useDevtoolsIgnoreList: true // DevTools Ignore List 사용 여부 - 기본값 true로 변경
    };
    
    // 설정 UI 간소화 - DevTools Ignore List 기능만 유지
    const settingsHTML = `
      <div class="diagram-settings">
        <div class="settings-form">
          <div class="settings-group">
            <label>
              <input type="checkbox" id="useDevtoolsIgnoreList" checked> DevTools Ignore List 사용
              <span class="setting-hint">Settings > Ignore List의 'Custom exclusion rules' 적용</span>
            </label>
          </div>
        </div>
      </div>
    `;
    
    // DevTools Ignore List 가져오기 함수
    function getDevtoolsIgnoreList() {
      return new Promise((resolve) => {
        try {
          // Chrome DevTools API를 사용하여 Ignore List 가져오기
          chrome.devtools.inspectedWindow.eval(
            `(function() {
              try {
                // 기본 무시 목록 설정
                const defaultIgnoreList = ['node_modules', 'jquery', 'react.development', 'angular', 'babel', 'webpack', 'polyfill'];
                
                // DevTools 설정에서 Custom exclusion patterns 가져오기 시도
                if (typeof chrome !== 'undefined' && chrome.devtools && chrome.devtools.network) {
                  return {
                    success: true,
                    ignoreList: defaultIgnoreList
                  };
                }
                
                return {
                  success: true,
                  ignoreList: defaultIgnoreList
                };
              } catch (e) {
                return {
                  success: false,
                  error: e.toString(),
                  ignoreList: []
                };
              }
            })()`,
            function(result, exceptionInfo) {
              if (exceptionInfo || !result || !result.success) {
                console.log('DevTools Ignore List 가져오기 오류:', exceptionInfo || result?.error || 'Unknown error');
                resolve([]);
                return;
              }
              
              resolve(result.ignoreList || []);
            }
          );
        } catch (e) {
          console.error('DevTools Ignore List 가져오기 실패:', e);
          resolve([]);
        }
      });
    }
    
    // 필터링된 프레임
    let filteredFrames = [...frames];
    
    // Mermaid 다이어그램 문법 생성 - 다이어그램 타입 적용
    let mermaidCode = '';
    
    // 다이어그램 유형에 따라 시작 코드 다르게 생성
    if (diagramType === 'flowchart') {
      mermaidCode = `---\ntitle: 스택 트레이스 다이어그램\n---\nflowchart ${direction}\n`;
      
      // 플로우차트 노드 및 엣지 생성 코드 - 단순화된 버전
      let prevNodeId = null;
      
      // 역순으로 처리 (스택 트레이스 호출 순서대로)
      for (let i = frames.length - 1; i >= 0; i--) {
        const frame = frames[i];
        // 노드 ID 순서 변경 - 최신 호출(첫번째)이 node0이 되도록
        const nodeId = `node${frames.length - 1 - i}`;
        const fileName = frame.fileName.replace(/[^\w-]/g, '_'); // 특수문자 제거
        const funcName = frame.functionName.replace(/[^\w-]/g, '_'); // 특수문자 제거
        
        // 노드 스타일 설정 (넥사크로 파일과 일반 파일 구분)
        const isNexacroFile = fileName.includes('nexacro') || fileName.includes('xfdl_js');
        
        // 노드 텍스트 생성 (단순화)
        const nodeLabel = `"${fileName}<br/>${funcName}<br/>(${frame.lineNumber})"`;
        
        // 노드 추가 (스타일을 별도로 지정하지 않음)
        if (isNexacroFile) {
          mermaidCode += `  ${nodeId}[${nodeLabel}]\n`;
        } else {
          mermaidCode += `  ${nodeId}(${nodeLabel})\n`;
        }
        
        // 이전 노드와 연결 (엣지 추가) - 화살표 방향 변경
        if (prevNodeId !== null) {
          // 호출 순서 번호 추가 - 최근 호출이 1번이 되도록
          const callOrder = frames.length - i;
          mermaidCode += `  ${prevNodeId} -->|"${callOrder}"| ${nodeId}\n`;
        }
        
        prevNodeId = nodeId;
      }
      
      // 클래스 정의 제거 (노드 모양으로 구분)
      
      // 명시적으로 renderFullDiagram 함수 호출 추가
      renderFullDiagram(mermaidCode, settingsHTML);
      return;
    } else if (diagramType === 'sequence') {
      mermaidCode = `---\ntitle: 스택 트레이스 다이어그램\n---\nsequenceDiagram\n`;
      
      // 각 프레임을 시퀀스 다이어그램 형식으로 추가
      for (let i = frames.length - 1; i > 0; i--) {
        const current = frames[i];
        const next = frames[i-1];
        
        // 시퀀스 다이어그램 구문 생성 - 파일명에서 특수문자 제거
        const currentId = current.fileName.replace(/[\.\-\s]/g, '_');
        const nextId = next.fileName.replace(/[\.\-\s]/g, '_');
        
        // 호출 순서 번호 추가 - 최근 호출이 1번이 되도록
        const callOrder = frames.length - i;
        // 화살표 방향 변경 (current가 next를 호출하는 것이 아니라, next가 current에 의해 호출됨)
        mermaidCode += `  ${nextId}->>+${currentId}: ${callOrder}: ${next.functionName} 호출\n`;
      }
      
      // 결과 반환은 마지막에만 추가
      if (frames.length > 1) {
        const lastFrame = frames[frames.length - 1];
        const secondLastFrame = frames[frames.length - 2];
        mermaidCode += `  ${secondLastFrame.fileName.replace(/[\.\-\s]/g, '_')}-->>-${lastFrame.fileName.replace(/[\.\-\s]/g, '_')}: 결과 반환\n`;
      }
      
      // 여기서 나머지 코드 생성하지 않고 바로 반환
      console.log("생성된 Mermaid 코드 (시퀀스):", mermaidCode);
      
      // renderMermaidDiagramToElement 대신 기존 코드 사용
    mermaidOutput.innerHTML = `
      ${settingsHTML}
      <div class="diagram-header">
          <button id="saveDiagramBtn" class="save-button">SVG로 저장</button>
        <button id="saveTraceBtn" class="save-button">스택 트레이스 저장</button>
        <button id="saveSourceBtn" class="save-button">소스코드 저장</button>
          <button id="saveAllBtn" class="save-button primary">모두 저장</button>
        <button id="toggleCodeBtn" class="toggle-button">Mermaid 코드 보기</button>
      </div>
      <div id="mermaid-container" class="diagram-container"></div>
      <div id="mermaidCodeContainer" class="mermaid-code-container" style="display: none;">
        <textarea class="mermaid-code" id="mermaidCodeEditor">${mermaidCode}</textarea>
        <div class="code-edit-actions">
          <button id="copyCodeBtn" class="code-action-button">코드 복사</button>
          <button id="applyCodeBtn" class="code-action-button primary">코드 변경사항 적용</button>
        </div>
      </div>
    `;
    
    try {
        // Mermaid 초기화 및 렌더링
      mermaid.initialize({
        startOnLoad: false,
        securityLevel: 'loose',
        theme: 'default',
          fontFamily: 'Arial, "맑은 고딕", "Malgun Gothic", sans-serif',
          fontSize: 16,
        sequence: {
          useMaxWidth: false,
            width: 200,
            height: 60,
            boxMargin: 20,
            boxTextMargin: 16,
            noteMargin: 20,
            messageMargin: 60
          }
        });
      
      // 다이어그램 컨테이너 요소 가져오기
      const container = document.getElementById('mermaid-container');
      
        // 렌더링 함수 정의
        const renderDiagram = (code) => {
          try {
            console.log('시퀀스 다이어그램 렌더링 시작:', code.substring(0, 100));
          
          // 렌더링을 위한 고유 ID 생성
          const id = 'mermaid-diagram-' + Date.now();
          
          // 렌더링 전 컨테이너에 로딩 표시
          container.innerHTML = '<div class="loading">다이어그램 생성 중...</div>';
          
          // mermaid.render API 사용
            mermaid.render(id, code)
            .then(result => {
              console.log('Mermaid 렌더링 성공');
              // 결과 SVG 삽입
              container.innerHTML = result.svg;
              
              // SVG 스타일링 개선
              const svgElement = container.querySelector('svg');
              if (svgElement) {
                // SVG 사이즈 조정
                svgElement.setAttribute('width', '100%');
                svgElement.setAttribute('height', 'auto');
                svgElement.style.maxHeight = '800px';
                svgElement.style.minHeight = '300px';
                
                // 노드 클릭 이벤트 추가
                setTimeout(() => {
                  setupNodeClickEvents(svgElement, frames);
                }, 200);
              }
            })
            .catch(err => {
              console.error('Mermaid 렌더링 오류:', err);
              container.innerHTML = `
                <div class="error">
                  <h3>다이어그램 렌더링 실패</h3>
                  <p>${err.message || '알 수 없는 오류'}</p>
                  <pre>${err.str || (err.stack || '')}</pre>
                    <p>문법을 확인해주세요.</p>
                </div>
              `;
            });
        } catch (error) {
          console.error('Mermaid 렌더링 함수 호출 오류:', error);
          container.innerHTML = `
            <div class="error">
              <h3>렌더링 함수 호출 오류</h3>
              <p>${error.message || '알 수 없는 오류'}</p>
              <pre>${error.stack || ''}</pre>
            </div>
          `;
        }
        };
      
      // 초기 렌더링
      renderDiagram(mermaidCode);
      
      // 버튼 이벤트 리스너 추가
      setTimeout(() => {
          // SVG 저장 버튼
        const saveDiagramBtn = document.getElementById('saveDiagramBtn');
        if (saveDiagramBtn) {
          saveDiagramBtn.addEventListener('click', () => {
            const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
              saveDiagramAsPNG(null, `stack-trace-diagram-${timestamp}.svg`);
          });
        }
        
        // 스택 트레이스 저장 버튼
        const saveTraceBtn = document.getElementById('saveTraceBtn');
        if (saveTraceBtn) {
          saveTraceBtn.addEventListener('click', () => {
            if (window.currentStackTrace) {
              const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
              saveStackTraceAsText(window.currentStackTrace, `stack-trace-${timestamp}.txt`);
            } else {
              alert('저장할 스택 트레이스가 없습니다.');
            }
          });
        }
        
        // 소스코드 저장 버튼
        const saveSourceBtn = document.getElementById('saveSourceBtn');
        if (saveSourceBtn) {
          saveSourceBtn.addEventListener('click', () => {
            if (parsedStack) {
            const sourceCodeText = generateSourceTextForDownload(parsedStack);
            if (sourceCodeText) {
              const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
              saveSourceCodeAsText(sourceCodeText, `stack-source-${timestamp}.txt`);
              } else {
                alert('저장할 소스 코드가 없습니다.');
              }
            } else {
              alert('저장할 소스 코드가 없습니다.');
            }
          });
        }
        
          // 모두 저장 버튼
          const saveAllBtn = document.getElementById('saveAllBtn');
          if (saveAllBtn) {
            saveAllBtn.addEventListener('click', () => {
              // 현재 파싱된 스택 저장
              window.parsedStack = parsedStack;
              // 모든 데이터 저장 함수 호출
              saveAllData();
          });
        }
        
        // 코드 표시 토글 버튼 처리
        const toggleCodeBtn = document.getElementById('toggleCodeBtn');
        const codeContainer = document.getElementById('mermaidCodeContainer');

        console.log('토글 버튼 설정 확인:', !!toggleCodeBtn, !!codeContainer);

        if (toggleCodeBtn && codeContainer) {
          // 직접 onclick 속성 할당 (이벤트 리스너 대신)
          toggleCodeBtn.onclick = function() {
            console.log('토글 버튼 클릭됨');
            
            // 현재 상태 확인 및 반전
            if (codeContainer.style.display === 'none' || codeContainer.style.display === '') {
              codeContainer.style.display = 'block';
              toggleCodeBtn.textContent = 'Mermaid 코드 숨기기';
            } else {
              codeContainer.style.display = 'none';
              toggleCodeBtn.textContent = 'Mermaid 코드 보기';
            }
          };
        } else {
          console.error('토글 버튼 또는 코드 컨테이너를 찾을 수 없음');
        }
        
        // 코드 복사 버튼
        const copyCodeBtn = document.getElementById('copyCodeBtn');
        const codeTextarea = document.querySelector('.mermaid-code');
        if (copyCodeBtn && codeTextarea) {
          copyCodeBtn.addEventListener('click', () => {
            codeTextarea.select();
            document.execCommand('copy');
            copyCodeBtn.textContent = '복사 완료!';
            setTimeout(() => {
              copyCodeBtn.textContent = '코드 복사';
            }, 2000);
          });
        } else {
          console.error('복사 버튼 또는 코드 에디터를 찾을 수 없음:',
                       copyCodeBtn ? '복사 버튼 있음' : '복사 버튼 없음',
                       codeTextarea ? '코드 에디터 있음' : '코드 에디터 없음');
        }
        
        // 코드 변경사항 적용 버튼
        const applyCodeBtn = document.getElementById('applyCodeBtn');
        const mermaidCodeEditor = document.getElementById('mermaidCodeEditor');
        if (applyCodeBtn && mermaidCodeEditor) {
          applyCodeBtn.addEventListener('click', () => {
            try {
              const newCode = mermaidCodeEditor.value;
              if (!newCode.trim()) {
                alert('Mermaid 코드가 비어있습니다.');
                return;
              }
              
              // 새 코드로 다이어그램 다시 렌더링
              renderDiagram(newCode);
              
              // 성공 메시지
              applyCodeBtn.textContent = '적용 완료!';
              setTimeout(() => {
                applyCodeBtn.textContent = '코드 변경사항 적용';
              }, 1500);
            } catch (error) {
              console.error('Mermaid 코드 적용 오류:', error);
              alert(`Mermaid 코드 적용 중 오류가 발생했습니다: ${error.message}`);
            }
          });
        }
      }, 100);
    } catch (error) {
        console.error('시퀀스 다이어그램 렌더링 오류:', error);
      mermaidOutput.innerHTML += `<p class="error-message">다이어그램 생성 중 오류가 발생했습니다: ${error.message}</p>`;
      }
      
      return;
    } else if (diagramType === 'class') {
      mermaidCode = `---\ntitle: 스택 트레이스 클래스 다이어그램\n---\nclassDiagram\n`;
      
      // 파일별 클래스 생성
      const fileClasses = {};
      
      // 각 파일을 클래스로 변환
      frames.forEach(frame => {
        const className = frame.fileName.replace(/[\.\-\s]/g, '_');
        if (!fileClasses[className]) {
          fileClasses[className] = {
            methods: new Set(),
            relations: new Set()
          };
        }
        
        // 메소드 추가 (함수명과 라인 번호)
        fileClasses[className].methods.add(`+${frame.functionName}(line:${frame.lineNumber})`)
      });
      
      // 호출 관계 추가 (역순)
      for (let i = frames.length - 1; i > 0; i--) {
        const caller = frames[i].fileName.replace(/[\.\-\s]/g, '_');
        const callee = frames[i-1].fileName.replace(/[\.\-\s]/g, '_');
        
        // 같은 클래스가 아닌 경우에만 관계 추가
        if (caller !== callee) {
          fileClasses[caller].relations.add(`${caller} ..> ${callee} : 호출`);
        }
      }
      
      // 클래스 다이어그램 코드 생성
      for (const [className, classData] of Object.entries(fileClasses)) {
        // 클래스 정의 추가
        mermaidCode += `  class ${className} {\n`;
        
        // 메소드 추가
        for (const method of classData.methods) {
          mermaidCode += `    ${method}\n`;
        }
        
        mermaidCode += `  }\n\n`;
        
        // 관계 추가
        for (const relation of classData.relations) {
          mermaidCode += `  ${relation}\n`;
        }
      }
      
      renderFullDiagram(mermaidCode, settingsHTML);
      return;
    } else if (diagramType === 'state') {
      mermaidCode = `---\ntitle: 스택 트레이스 상태 다이어그램\n---\nstateDiagram\n`;
      
      // 각 프레임을 상태 다이어그램 형식으로 추가
      for (let i = frames.length - 1; i > 0; i--) {
        const current = frames[i];
        const next = frames[i-1];
        
        // 상태 다이어그램 구문 생성 - 파일명에서 특수문자 제거
        const currentId = current.fileName.replace(/[\.\-\s]/g, '_');
        const nextId = next.fileName.replace(/[\.\-\s]/g, '_');
        
        // 호출 순서 번호 추가 - 최근 호출이 1번이 되도록
        const callOrder = frames.length - i;
        // 화살표 방향 변경 (current가 next를 호출하는 것이 아니라, next가 current에 의해 호출됨)
        mermaidCode += `  ${nextId}->>+${currentId}: ${callOrder}: ${next.functionName} 호출\n`;
      }
      
      // 결과 반환은 마지막에만 추가
      if (frames.length > 1) {
        const lastFrame = frames[frames.length - 1];
        const secondLastFrame = frames[frames.length - 2];
        mermaidCode += `  ${secondLastFrame.fileName.replace(/[\.\-\s]/g, '_')}-->>-${lastFrame.fileName.replace(/[\.\-\s]/g, '_')}: 결과 반환\n`;
      }
      
      // 여기서 나머지 코드 생성하지 않고 바로 반환
      console.log("생성된 Mermaid 코드 (상태):", mermaidCode);
      
      // renderMermaidDiagramToElement 대신 기존 코드 사용
    mermaidOutput.innerHTML = `
      ${settingsHTML}
      <div class="diagram-header">
          <button id="saveDiagramBtn" class="save-button">SVG로 저장</button>
        <button id="saveTraceBtn" class="save-button">스택 트레이스 저장</button>
        <button id="saveSourceBtn" class="save-button">소스코드 저장</button>
          <button id="saveAllBtn" class="save-button primary">모두 저장</button>
        <button id="toggleCodeBtn" class="toggle-button">Mermaid 코드 보기</button>
      </div>
      <div id="mermaid-container" class="diagram-container"></div>
      <div id="mermaidCodeContainer" class="mermaid-code-container" style="display: none;">
        <textarea class="mermaid-code" id="mermaidCodeEditor">${mermaidCode}</textarea>
        <div class="code-edit-actions">
          <button id="copyCodeBtn" class="code-action-button">코드 복사</button>
          <button id="applyCodeBtn" class="code-action-button primary">코드 변경사항 적용</button>
        </div>
      </div>
    `;
    
    try {
        // Mermaid 초기화 및 렌더링
      mermaid.initialize({
        startOnLoad: false,
        securityLevel: 'loose',
        theme: 'default',
          fontFamily: 'Arial, "맑은 고딕", "Malgun Gothic", sans-serif',
          fontSize: 16,
        stateDiagram: {
          useMaxWidth: false,
            width: 200,
            height: 60,
            boxMargin: 20,
            boxTextMargin: 16,
            noteMargin: 20,
            messageMargin: 60
          }
        });
      
      // 다이어그램 컨테이너 요소 가져오기
      const container = document.getElementById('mermaid-container');
      
        // 렌더링 함수 정의
        const renderDiagram = (code) => {
          try {
            console.log('상태 다이어그램 렌더링 시작:', code.substring(0, 100));
          
          // 렌더링을 위한 고유 ID 생성
          const id = 'mermaid-diagram-' + Date.now();
          
          // 렌더링 전 컨테이너에 로딩 표시
          container.innerHTML = '<div class="loading">다이어그램 생성 중...</div>';
          
          // mermaid.render API 사용
            mermaid.render(id, code)
            .then(result => {
              console.log('Mermaid 렌더링 성공');
              // 결과 SVG 삽입
              container.innerHTML = result.svg;
              
              // SVG 스타일링 개선
              const svgElement = container.querySelector('svg');
              if (svgElement) {
                // SVG 사이즈 조정
                svgElement.setAttribute('width', '100%');
                svgElement.setAttribute('height', 'auto');
                svgElement.style.maxHeight = '800px';
                svgElement.style.minHeight = '300px';
                
                // 노드 클릭 이벤트 추가
                setTimeout(() => {
                  setupNodeClickEvents(svgElement, frames);
                }, 200);
              }
            })
            .catch(err => {
              console.error('Mermaid 렌더링 오류:', err);
              container.innerHTML = `
                <div class="error">
                  <h3>다이어그램 렌더링 실패</h3>
                  <p>${err.message || '알 수 없는 오류'}</p>
                  <pre>${err.str || (err.stack || '')}</pre>
                    <p>문법을 확인해주세요.</p>
                </div>
              `;
            });
        } catch (error) {
          console.error('Mermaid 렌더링 함수 호출 오류:', error);
          container.innerHTML = `
            <div class="error">
              <h3>렌더링 함수 호출 오류</h3>
              <p>${error.message || '알 수 없는 오류'}</p>
              <pre>${error.stack || ''}</pre>
            </div>
          `;
        }
        };
      
      // 초기 렌더링
      renderDiagram(mermaidCode);
      
      // 버튼 이벤트 리스너 추가
      setTimeout(() => {
          // SVG 저장 버튼
        const saveDiagramBtn = document.getElementById('saveDiagramBtn');
        if (saveDiagramBtn) {
          saveDiagramBtn.addEventListener('click', () => {
            const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
              saveDiagramAsPNG(null, `stack-trace-diagram-${timestamp}.svg`);
          });
        }
        
        // 스택 트레이스 저장 버튼
        const saveTraceBtn = document.getElementById('saveTraceBtn');
        if (saveTraceBtn) {
          saveTraceBtn.addEventListener('click', () => {
            if (window.currentStackTrace) {
              const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
              saveStackTraceAsText(window.currentStackTrace, `stack-trace-${timestamp}.txt`);
              } else {
              alert('저장할 스택 트레이스가 없습니다.');
            }
          });
        }
        
        // 소스코드 저장 버튼
        const saveSourceBtn = document.getElementById('saveSourceBtn');
        if (saveSourceBtn) {
          saveSourceBtn.addEventListener('click', () => {
            if (parsedStack) {
            const sourceCodeText = generateSourceTextForDownload(parsedStack);
            if (sourceCodeText) {
              const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
              saveSourceCodeAsText(sourceCodeText, `stack-source-${timestamp}.txt`);
          } else {
                alert('저장할 소스 코드가 없습니다.');
              }
            } else {
              alert('저장할 소스 코드가 없습니다.');
      }
    });
  }
  
          // 모두 저장 버튼
          const saveAllBtn = document.getElementById('saveAllBtn');
          if (saveAllBtn) {
            saveAllBtn.addEventListener('click', () => {
              // 현재 파싱된 스택 저장
              window.parsedStack = parsedStack;
              // 모든 데이터 저장 함수 호출
              saveAllData();
          });
        }
        
        // 코드 표시 토글 버튼 처리
        const toggleCodeBtn = document.getElementById('toggleCodeBtn');
        const codeContainer = document.getElementById('mermaidCodeContainer');

        console.log('토글 버튼 설정 확인:', !!toggleCodeBtn, !!codeContainer);

        if (toggleCodeBtn && codeContainer) {
          // 직접 onclick 속성 할당 (이벤트 리스너 대신)
          toggleCodeBtn.onclick = function() {
            console.log('토글 버튼 클릭됨');
            
            // 현재 상태 확인 및 반전
            if (codeContainer.style.display === 'none' || codeContainer.style.display === '') {
              codeContainer.style.display = 'block';
              toggleCodeBtn.textContent = 'Mermaid 코드 숨기기';
            } else {
              codeContainer.style.display = 'none';
              toggleCodeBtn.textContent = 'Mermaid 코드 보기';
            }
          };
            } else {
          console.error('토글 버튼 또는 코드 컨테이너를 찾을 수 없음');
        }
        
        // 코드 복사 버튼
        const copyCodeBtn = document.getElementById('copyCodeBtn');
        const codeTextarea = document.querySelector('.mermaid-code');
        if (copyCodeBtn && codeTextarea) {
          copyCodeBtn.addEventListener('click', () => {
            codeTextarea.select();
            document.execCommand('copy');
            copyCodeBtn.textContent = '복사 완료!';
            setTimeout(() => {
              copyCodeBtn.textContent = '코드 복사';
            }, 2000);
          });
              } else {
          console.error('복사 버튼 또는 코드 에디터를 찾을 수 없음:',
                       copyCodeBtn ? '복사 버튼 있음' : '복사 버튼 없음',
                       codeTextarea ? '코드 에디터 있음' : '코드 에디터 없음');
        }
        
        // 코드 변경사항 적용 버튼
        const applyCodeBtn = document.getElementById('applyCodeBtn');
        const mermaidCodeEditor = document.getElementById('mermaidCodeEditor');
        if (applyCodeBtn && mermaidCodeEditor) {
          applyCodeBtn.addEventListener('click', () => {
            try {
              const newCode = mermaidCodeEditor.value;
              if (!newCode.trim()) {
                alert('Mermaid 코드가 비어있습니다.');
                return;
              }
              
              // 새 코드로 다이어그램 다시 렌더링
              renderDiagram(newCode);
              
              // 성공 메시지
              applyCodeBtn.textContent = '적용 완료!';
              setTimeout(() => {
                applyCodeBtn.textContent = '코드 변경사항 적용';
              }, 1500);
            } catch (error) {
              console.error('Mermaid 코드 적용 오류:', error);
              alert(`Mermaid 코드 적용 중 오류가 발생했습니다: ${error.message}`);
        }
      });
    }
      }, 100);
  } catch (error) {
        console.error('상태 다이어그램 렌더링 오류:', error);
      mermaidOutput.innerHTML += `<p class="error-message">다이어그램 생성 중 오류가 발생했습니다: ${error.message}</p>`;
      }
      
      return;
    } else {
      // 다른 다이어그램 타입은 기본 플로우차트로 폴백
      mermaidCode = `---\ntitle: 스택 트레이스 다이어그램\n---\nflowchart ${direction}\n`;
    }
    
    // 다이어그램 렌더링을 위한 공통 함수
    function renderFullDiagram(code, settingsHTML) {
      // 현재 내용을 완전히 대체
      mermaidOutput.innerHTML = `
      ${settingsHTML}
      <div class="diagram-header">
        <button id="saveDiagramBtn" class="save-button">PNG로 저장</button>
        <button id="saveTraceBtn" class="save-button">스택 트레이스 저장</button>
        <button id="saveSourceBtn" class="save-button">소스코드 저장</button>
        <button id="toggleCodeBtn" class="toggle-button">Mermaid 코드 보기</button>
      </div>
      <div id="mermaid-container" class="diagram-container"></div>
      <div id="mermaidCodeContainer" class="mermaid-code-container" style="display: none;">
        <textarea class="mermaid-code" id="mermaidCodeEditor">${code}</textarea>
        <div class="code-edit-actions">
          <button id="copyCodeBtn" class="code-action-button">코드 복사</button>
          <button id="applyCodeBtn" class="code-action-button primary">코드 변경사항 적용</button>
        </div>
      </div>
    `;
    
    try {
        // Mermaid 초기화 및 렌더링 설정
      mermaid.initialize({
        startOnLoad: false,
        securityLevel: 'loose',
        theme: 'default',
          fontFamily: 'Arial, "맑은 고딕", "Malgun Gothic", sans-serif',
          fontSize: 16,
        flowchart: {
          useMaxWidth: false,
          htmlLabels: true,
            curve: 'basis'
          },
        sequence: {
          useMaxWidth: false,
            width: 200,
            height: 60
          },
          classDiagram: {
            useMaxWidth: false,
            diagramPadding: 20
          },
          stateDiagram: {
            useMaxWidth: false,
            diagramPadding: 20
          },
          er: {
            useMaxWidth: false,
            diagramPadding: 20,
            layoutDirection: 'TB'
          }
        });
      
      // 다이어그램 컨테이너 요소 가져오기
      const container = document.getElementById('mermaid-container');
      
        // 렌더링 함수 정의
        const renderDiagram = (code) => {
          try {
            console.log('다이어그램 렌더링 시작');
          
          // 렌더링 전 컨테이너에 로딩 표시
          container.innerHTML = '<div class="loading">다이어그램 생성 중...</div>';
          
          // mermaid.render API 사용
            mermaid.render('mermaid-diagram-' + Date.now(), code)
            .then(result => {
              console.log('Mermaid 렌더링 성공');
              // 결과 SVG 삽입
              container.innerHTML = result.svg;
              
              // SVG 스타일링 개선
              const svgElement = container.querySelector('svg');
              if (svgElement) {
                // SVG 사이즈 조정
                svgElement.setAttribute('width', '100%');
                svgElement.setAttribute('height', 'auto');
                svgElement.style.maxHeight = '800px';
                svgElement.style.minHeight = '300px';
                
                // 노드 클릭 이벤트 추가
                setTimeout(() => {
                  setupNodeClickEvents(svgElement, frames);
                }, 200);
              }
            })
            .catch(err => {
              console.error('Mermaid 렌더링 오류:', err);
              container.innerHTML = `
                <div class="error">
                  <h3>다이어그램 렌더링 실패</h3>
                  <p>${err.message || '알 수 없는 오류'}</p>
                  <pre>${err.str || (err.stack || '')}</pre>
                    <p>문법을 확인해주세요.</p>
                </div>
              `;
            });
        } catch (error) {
          console.error('Mermaid 렌더링 함수 호출 오류:', error);
          container.innerHTML = `
            <div class="error">
              <h3>렌더링 함수 호출 오류</h3>
              <p>${error.message || '알 수 없는 오류'}</p>
              <pre>${error.stack || ''}</pre>
            </div>
          `;
        }
        };
      
      // 초기 렌더링
        renderDiagram(code);
      
        // 1초 후에 버튼 이벤트 리스너 설정 (DOM이 완전히 로드된 후)
      setTimeout(() => {
          // Mermaid 코드 보기 버튼 설정 - 최우선적으로 처리
          const codeContainer = document.getElementById('mermaidCodeContainer');
          const toggleCodeBtn = document.getElementById('toggleCodeBtn');
          
          if (toggleCodeBtn && codeContainer) {
            console.log('토글 버튼 찾음, 이벤트 설정');
            
            // 기존 이벤트 제거를 위해 새로운 버튼으로 교체
            const newToggleBtn = toggleCodeBtn.cloneNode(true);
            toggleCodeBtn.parentNode.replaceChild(newToggleBtn, toggleCodeBtn);
            
            // 명시적으로 속성으로 직접 이벤트 핸들러 할당
            newToggleBtn.addEventListener('click', function() {
              console.log('토글 버튼 클릭됨!');
              if (codeContainer.style.display === 'none' || codeContainer.style.display === '') {
                codeContainer.style.display = 'block';
                this.textContent = 'Mermaid 코드 숨기기';
              } else {
                codeContainer.style.display = 'none';
                this.textContent = 'Mermaid 코드 보기';
              }
            });
            
            // 초기 상태 확인
            console.log('코드 컨테이너 초기 상태:', codeContainer.style.display);
          } else {
            console.error('토글 버튼 또는 코드 컨테이너를 찾을 수 없음', {
              toggleBtn: !!toggleCodeBtn,
              codeContainer: !!codeContainer
            });
        }
        
        // PNG 저장 버튼
        const saveDiagramBtn = document.getElementById('saveDiagramBtn');
        if (saveDiagramBtn) {
          saveDiagramBtn.addEventListener('click', () => {
            const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
            saveDiagramAsPNG(null, `stack-trace-diagram-${timestamp}.png`);
          });
        }
        
        // 스택 트레이스 저장 버튼
        const saveTraceBtn = document.getElementById('saveTraceBtn');
        if (saveTraceBtn) {
          saveTraceBtn.addEventListener('click', () => {
            if (window.currentStackTrace) {
              const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
              saveStackTraceAsText(window.currentStackTrace, `stack-trace-${timestamp}.txt`);
            } else {
              alert('저장할 스택 트레이스가 없습니다.');
            }
          });
        }
        
        // 소스코드 저장 버튼
        const saveSourceBtn = document.getElementById('saveSourceBtn');
        if (saveSourceBtn) {
          saveSourceBtn.addEventListener('click', () => {
              if (window.parsedStack) {
                const sourceCodeText = generateSourceTextForDownload(window.parsedStack);
            if (sourceCodeText) {
              const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
              saveSourceCodeAsText(sourceCodeText, `stack-source-${timestamp}.txt`);
                } else {
                  alert('저장할 소스 코드가 없습니다.');
                }
            } else {
              alert('저장할 소스 코드가 없습니다.');
            }
          });
        }
        
          // 코드 복사 및 적용 버튼
          const copyCodeBtn = document.getElementById('copyCodeBtn');
          const applyCodeBtn = document.getElementById('applyCodeBtn');
          const mermaidCodeEditor = document.getElementById('mermaidCodeEditor');
          
          if (copyCodeBtn && mermaidCodeEditor) {
            copyCodeBtn.addEventListener('click', () => {
              mermaidCodeEditor.select();
              document.execCommand('copy');
              copyCodeBtn.textContent = '복사 완료!';
              setTimeout(() => {
                copyCodeBtn.textContent = '코드 복사';
              }, 1500);
            });
          }
          
          if (applyCodeBtn && mermaidCodeEditor) {
            applyCodeBtn.addEventListener('click', () => {
              try {
                const newCode = mermaidCodeEditor.value;
                if (!newCode.trim()) {
                  alert('Mermaid 코드가 비어있습니다.');
                  return;
                }
                
                // 새 코드로 다이어그램 다시 렌더링
                renderDiagram(newCode);
                
                // 성공 메시지
                applyCodeBtn.textContent = '적용 완료!';
                setTimeout(() => {
                  applyCodeBtn.textContent = '코드 변경사항 적용';
                }, 1500);
              } catch (error) {
                console.error('Mermaid 코드 적용 오류:', error);
                alert(`Mermaid 코드 적용 중 오류가 발생했습니다: ${error.message}`);
              }
            });
          }
        }, 1000);
      } catch (error) {
        console.error('다이어그램 렌더링 초기화 오류:', error);
        mermaidOutput.innerHTML += `<p class="error-message">다이어그램 생성 중 오류가 발생했습니다: ${error.message}</p>`;
      }
    }
    
    // 코드 에디터 버튼 설정 함수
    function setupCodeEditorButtons(renderFunc) {
        // 소스코드 저장 버튼
        const saveSourceBtn = document.getElementById('saveSourceBtn');
        if (saveSourceBtn) {
          saveSourceBtn.addEventListener('click', () => {
          if (parsedStack) {
            const sourceCodeText = generateSourceTextForDownload(parsedStack);
            if (sourceCodeText) {
              const timestamp = new Date().toISOString().slice(0,19).replace(/[T:]/g, '-');
              saveSourceCodeAsText(sourceCodeText, `stack-source-${timestamp}.txt`);
            } else {
              alert('저장할 소스 코드가 없습니다.');
            }
          } else {
            alert('저장할 소스 코드가 없습니다.');
          }
          });
        }
        
        // 코드 복사 버튼
        const copyCodeBtn = document.getElementById('copyCodeBtn');
        const codeTextarea = document.querySelector('.mermaid-code');
        if (copyCodeBtn && codeTextarea) {
          copyCodeBtn.addEventListener('click', () => {
            codeTextarea.select();
            document.execCommand('copy');
            copyCodeBtn.textContent = '복사 완료!';
            setTimeout(() => {
              copyCodeBtn.textContent = '코드 복사';
            }, 1500);
          });
        } else {
          console.error('복사 버튼 또는 코드 에디터를 찾을 수 없음:',
                       copyCodeBtn ? '복사 버튼 있음' : '복사 버튼 없음',
                       codeTextarea ? '코드 에디터 있음' : '코드 에디터 없음');
        }
        
        // 코드 변경사항 적용 버튼
        const applyCodeBtn = document.getElementById('applyCodeBtn');
        const mermaidCodeEditor = document.getElementById('mermaidCodeEditor');
        if (applyCodeBtn && mermaidCodeEditor) {
          applyCodeBtn.addEventListener('click', () => {
            try {
              const newCode = mermaidCodeEditor.value;
              if (!newCode.trim()) {
                alert('Mermaid 코드가 비어있습니다.');
                return;
              }
              
              // 새 코드로 다이어그램 다시 렌더링
            renderFunc(newCode);
              
              // 성공 메시지
              applyCodeBtn.textContent = '적용 완료!';
              setTimeout(() => {
                applyCodeBtn.textContent = '코드 변경사항 적용';
              }, 1500);
            } catch (error) {
              console.error('Mermaid 코드 적용 오류:', error);
              alert(`Mermaid 코드 적용 중 오류가 발생했습니다: ${error.message}`);
            }
          });
        }
    }
  } // generateMermaidDiagram 함수의 끝
  
  /**
   * 현재 생성된 소스 코드를 텍스트 형식으로 추출하는 함수
   */
  async function generateSourceTextForDownload(parsedStack) {
    const { frames } = parsedStack;
    if (!frames || frames.length === 0) return null;
    
    let result = "# 스택 트레이스 소스 코드 요약\n\n";
    
    // 프레임 배열을 역순으로 변경 (가장 최근의 호출이 마지막에 오도록)
    const reversedFrames = frames.slice().reverse();
    
    // 비동기 작업을 위한 프라미스 배열
    const promises = reversedFrames.map(async (frame, index) => {
      // 함수 이름이 있으면 함수 이름으로 검색
      const functionName = frame.functionName && frame.functionName !== 'Anonymous function' ? frame.functionName : null;
      
      // 최근 호출이 1번이 되도록 표시
      const displayIndex = index + 1;
      
      const frameContent = `## ${displayIndex}. ${frame.fileName} - ${frame.functionName}\n` +
                          `파일 경로: ${frame.filePath}\n` +
                          `라인: ${frame.lineNumber}, 컬럼: ${frame.columnNumber}\n\n` +
                          "```javascript\n" +
                          await loadRemoteSourceCode(frame.filePath, frame.lineNumber, functionName) +
                          "\n```\n\n";
      return { index, content: frameContent };
    });
    
    // 모든 프레임 처리 대기
    const frameContents = await Promise.all(promises);
    
    // 원래 순서대로 결과 추가
    frameContents
      .sort((a, b) => a.index - b.index)
      .forEach(item => {
        result += item.content;
    });
    
    return result;
  }
  
  // XHR 캡처 이벤트 핸들러
  function handleXhrCaptured(event) {
    try {
      if (!isCapturing) return;
      
      const detail = event.detail;
      console.log('XHR 이벤트 직접 캡처:', detail);
      
      if (detail && detail.stack) {
        addCapturedXHR(detail);
      }
    } catch(error) {
      console.error('XHR 이벤트 처리 오류:', error);
    }
  }

  // 처음 로드 시 초기 탭 활성화
  try {
    console.log('초기 탭 활성화 시도');
    // 초기 상태에서 수동 입력 탭을 기본으로 활성화
    tabManual.click();
    console.log('수동 입력 탭 활성화됨');
  } catch (error) {
    console.error('초기 탭 활성화 오류:', error);
    debugLog('초기 탭 활성화 실패: ' + error.message);
  }

  /**
   * 파싱된 스택 트레이스로부터 소스 코드 섹션을 생성하는 함수
   */
  async function generateSourceCode(parsedStack) {
    const { frames } = parsedStack;
    
    if (!frames || frames.length === 0) {
      sourceCodeOutput.innerHTML = '<p>파싱할 스택 프레임이 없습니다.</p>';
      return;
    }
    
    // 프레임 배열을 역순으로 변경
    const reversedFrames = frames.slice().reverse();
    
    let html = '<div class="source-code-container">';
    html += '<h2>스택 트레이스 소스 코드</h2>';
    
    // 모든 소스 파일 다운로드 버튼 추가
    html += `<div class="source-download-all">
      <button id="downloadAllSourcesBtn" class="download-all-sources-btn">모든 소스 파일 다운로드</button>
    </div>`;
    
    // CSS 스타일 추가 (다운로드 버튼 스타일)
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      .download-full-source-btn,
      .download-all-sources-btn {
        background-color: #f8f9fa;
        border: 1px solid #dadce0;
        border-radius: 4px;
        color: #3c4043;
        cursor: pointer;
        font-size: 14px;
        padding: 6px 12px;
        margin-top: 8px;
        transition: all 0.2s ease-in-out;
      }
      
      .download-full-source-btn:hover,
      .download-all-sources-btn:hover {
        background-color: #e8eaed;
        box-shadow: 0 1px 2px rgba(60, 64, 67, 0.3);
      }
      
      .download-full-source-btn:active,
      .download-all-sources-btn:active {
        background-color: #dadce0;
      }
      
      .download-full-source-btn:disabled,
      .download-all-sources-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      .source-download-all {
        margin-bottom: 15px;
        text-align: right;
      }
      
      .download-all-sources-btn {
        background-color: #4285f4;
        color: white;
        font-weight: bold;
      }
      
      .download-all-sources-btn:hover {
        background-color: #3367d6;
      }
    `;
    document.head.appendChild(styleElement);
    
    // 각 프레임 정보를 HTML로 변환 (로딩 상태로 초기화)
    reversedFrames.forEach((frame, index) => {
      // 최근 호출이 1번이 되도록 표시
      const displayIndex = index + 1;
      
      html += `<div class="source-frame" id="frame-${index}">`;
      html += `<h3>${displayIndex}. ${frame.fileName} - ${frame.functionName}</h3>`;
      html += `<div class="frame-details">`;
      html += `<p><strong>파일 경로:</strong> ${frame.filePath}</p>`;
      html += `<p><strong>라인:</strong> ${frame.lineNumber}, <strong>컬럼:</strong> ${frame.columnNumber}</p>`;
      html += `</div>`;
      
      // 소스 코드 표시 (로딩 메시지로 초기화)
      html += `<div class="source-code">`;
      html += `<pre><code class="language-javascript">// 소스 코드 로딩 중...</code></pre>`;
      html += `</div></div>`;
    });
    
    html += '</div>';
    sourceCodeOutput.innerHTML = html;
    
    // 비동기로 각 프레임의 소스 코드 로드 및 업데이트
    reversedFrames.forEach(async (frame, index) => {
      try {
        // 함수 이름이 있으면, 함수 이름을 사용하여 소스코드 로드
        const functionName = frame.functionName && frame.functionName !== 'Anonymous function' ? frame.functionName : null;
        const codeContent = await loadRemoteSourceCode(frame.filePath, frame.lineNumber, functionName);
        const codeElement = document.querySelector(`#frame-${index} .source-code code`);
        if (codeElement) {
          codeElement.textContent = codeContent;
                }
              } catch (error) {
        console.error(`프레임 ${index} 소스 코드 로딩 오류:`, error);
        const codeElement = document.querySelector(`#frame-${index} .source-code code`);
        if (codeElement) {
          codeElement.textContent = `// 소스 코드 로딩 오류: ${error.message}`;
              }
            }
          });

    // 소스 전체 다운로드 버튼 이벤트 리스너 추가
    setTimeout(() => {
      // 개별 다운로드 버튼 이벤트 리스너 제거 - 이미 HTML에서 버튼 자체를 제거했으므로 이 부분도 제거
      
      // 모든 소스 파일 다운로드 버튼 이벤트 리스너 추가
      const downloadAllBtn = document.getElementById('downloadAllSourcesBtn');
      if (downloadAllBtn) {
        downloadAllBtn.addEventListener('click', async function() {
          try {
            // 버튼 상태 변경
            this.textContent = '다운로드 중...';
            this.disabled = true;
            
            // 중복 제거를 위한 파일 경로 집합 생성
            const uniqueFilePaths = new Set();
            reversedFrames.forEach(frame => {
              if (frame.filePath) {
                uniqueFilePaths.add(frame.filePath);
              }
            });
            
            // 파일 경로 배열로 변환
            const filePaths = Array.from(uniqueFilePaths);
            
            // 파일 경로가 없는 경우
            if (filePaths.length === 0) {
              alert('다운로드할 소스 파일이 없습니다.');
              this.textContent = '모든 소스 파일 다운로드';
              this.disabled = false;
              return;
            }
            
            // 진행 상태 표시
            let downloadCount = 0;
            this.textContent = `다운로드 중 (0/${filePaths.length})`;
            
            // 중복 방지를 위한 지연 시간 계산
            const delay = 800; // 파일당 대기 시간 (밀리초)
            
            // 모든 파일을 순차적으로 다운로드하지 않고 일괄 다운로드 시도
            const downloadPromises = filePaths.map((filePath, index) => {
              // 파일마다 시간차를 두고 다운로드 시작
              return new Promise(resolve => {
                setTimeout(async () => {
                  await downloadSourceFile(filePath);
                  downloadCount++;
                  this.textContent = `다운로드 중 (${downloadCount}/${filePaths.length})`;
                  resolve();
                }, index * delay);
              });
            });
            
            // 모든 다운로드 완료 대기
            await Promise.all(downloadPromises);
            
            // 완료 메시지
            this.textContent = '다운로드 완료!';
            setTimeout(() => {
              this.textContent = '모든 소스 파일 다운로드';
              this.disabled = false;
            }, 2000);
    } catch (error) {
            console.error('모든 소스 파일 다운로드 오류:', error);
            alert(`다운로드 오류: ${error.message}`);
            this.textContent = '모든 소스 파일 다운로드';
            this.disabled = false;
          }
        });
      }
    }, 100);
  }
  
  // 소스 파일 다운로드 함수 수정
  async function downloadSourceFile(filePath) {
    if (!filePath) {
      console.error('파일 경로가 유효하지 않습니다.');
      return false;
    }
    
    try {
      console.log(`파일 다운로드 시작: ${filePath}`);
      
      // CORS 우회를 위한 프록시 URL 사용
      let sourceCode = null;
      const proxyUrls = [
        filePath, // 직접 URL 먼저 시도
        `/proxy?url=${encodeURIComponent(filePath)}`, // 프록시 URL 사용
        `https://cors-anywhere.herokuapp.com/${filePath}` // CORS Anywhere 서비스 시도
      ];
      
      // 각 URL 순차적으로 시도
      for (const proxyUrl of proxyUrls) {
        try {
          console.log(`URL 시도: ${proxyUrl}`);
          const response = await fetch(proxyUrl);
          if (response.ok) {
            sourceCode = await response.text();
            console.log(`소스코드 로드 성공 (${proxyUrl})`);
            break;
          }
        } catch (fetchError) {
          console.warn(`URL 실패 (${proxyUrl}):`, fetchError);
        }
      }
      
      // 소스 코드 가져오기 실패 시
      if (!sourceCode) {
        console.warn('소스 코드 가져오기 실패:', filePath);
        return false;
      }
      
      // 파일명 추출 (쿼리 파라미터 제거)
      const urlWithoutQuery = filePath.split('?')[0];
      const fileName = urlWithoutQuery.split(/[\\/]/).pop() || 'source.js';
      
      // 파일 다운로드
      const blob = new Blob([sourceCode], {type: 'text/plain'});
      const url = URL.createObjectURL(blob);
      
      // 다운로드 링크 생성
      const link = document.createElement('a');
      link.download = fileName;
      link.href = url;
      
      // 링크 클릭하여 다운로드
      document.body.appendChild(link);
      link.click();
      
      // 정리
      document.body.removeChild(link);
      setTimeout(() => {
        URL.revokeObjectURL(url);
      }, 100);
      
      console.log(`파일 다운로드 완료: ${fileName}`);
      return true;
    } catch (error) {
      console.error('파일 다운로드 오류:', error, filePath);
      return false;
    }
  }

  // 샘플 만들기 버튼 이벤트 리스너
  const createSampleBtn = document.getElementById('createSampleBtn');
  if (createSampleBtn) {
    createSampleBtn.addEventListener('click', function() {
      const diagramType = mermaidTypeSelect.value;
      const direction = mermaidDirectionSelect.value;
      
      // 선택된 다이어그램 종류와 방향에 맞는 샘플 코드 생성
      mermaidEditor.value = getMermaidSampleCode(diagramType, direction);
      
      // 에디터에 포커스
      mermaidEditor.focus();
    });
  }

  // 다이어그램 유형과 방향 변경 시 방향 선택 표시 여부 설정
  mermaidTypeSelect.addEventListener('change', function() {
    const diagramType = mermaidTypeSelect.value;
    const direction = mermaidDirectionSelect.value;
    
    // 다이어그램 방향 선택 표시 여부 설정
    const showDirection = diagramType === 'flowchart';
    mermaidDirectionSelect.parentElement.style.display = showDirection ? 'block' : 'none';
  });
  
  mermaidDirectionSelect.addEventListener('change', function() {
    // 추가 코드 없음 - 샘플 버튼을 별도로 클릭해야 업데이트
  });

  // 초기화 시 다이어그램 종류에 따라 방향 선택 표시 여부 설정
  const initialDiagramType = mermaidTypeSelect.value;
  mermaidDirectionSelect.parentElement.style.display = initialDiagramType === 'flowchart' ? 'block' : 'none';

  // 수동 입력 모드에서 변환 버튼 클릭 이벤트
  document.getElementById('processButton').addEventListener('click', function() {
    try {
      // 스택 트레이스 입력 가져오기
      const stackTrace = stackTraceInput.value.trim();
      
      if (!stackTrace) {
        alert('스택 트레이스를 입력해주세요.');
                return;
              }
              
      // 설정 가져오기
      const mermaidType = document.getElementById('manualMermaidTypeSelect').value;
      const mermaidDirection = document.getElementById('manualMermaidDirectionSelect').value;
      
      // 다이어그램 옵션
                  const diagramOptions = {
        type: mermaidType,
        direction: mermaidDirection
      };
      
      debugLog(`변환 요청: ${mermaidType} 다이어그램, 방향 ${mermaidDirection}`);
      
      // 스택 트레이스 처리
      processStackTrace(stackTrace, diagramOptions);
      
      } catch (error) {
      console.error('스택 트레이스 변환 오류:', error);
      handleError(error, '스택 트레이스 변환 중 오류 발생', mermaidOutput);
      }
  });

  // 실제 파일 내용을 읽어오는 새로운 함수
  async function readFileContent(filePath, lineNumber) {
    try {
      // 파일 경로 정규화 (상대 경로 -> 절대 경로 변환)
      const normalizedPath = filePath.replace(/\\/g, '/');
      console.log(`파일 읽기 시도: ${normalizedPath}`);
      
      // 파일이 존재하는지 확인하고 내용 읽기 (fetch 사용)
      // 주: 보안 제한으로 인해 브라우저에서 직접 파일 시스템 접근이 불가능할 수 있음
      // 따라서 가상의 파일 시스템 또는 서버 측 기능이 있다고 가정
      let fileContent = null;
      
      try {
        // 파일 접근 시도 (실제 개발 환경에서는 서버 API를 호출하거나 다른 방법 필요)
        const response = await fetch(`/api/readFile?path=${encodeURIComponent(normalizedPath)}`);
        if (response.ok) {
          fileContent = await response.text();
        }
      } catch (error) {
        console.warn(`파일 접근 실패 (${normalizedPath}):`, error);
      }
      
      // 파일 접근 실패 시 가상 코드 생성 (기존 방식)
      if (!fileContent) {
        console.log('파일 접근 실패, 가상 코드 생성');
        return generateMockFileContent(filePath, lineNumber);
      }
      
      // 파일 내용에서 해당 라인 주변 코드 추출
      const lines = fileContent.split('\n');
      const startLine = Math.max(0, lineNumber - 5);
      const endLine = Math.min(lines.length, lineNumber + 10);
      const relevantLines = lines.slice(startLine, endLine);
      
      // 라인 번호와 함께 코드 조합
      let result = `// ${filePath} (${startLine+1}-${endLine})\n`;
      relevantLines.forEach((line, index) => {
        const currentLineNumber = startLine + index + 1;
        const linePrefix = currentLineNumber === lineNumber ? '>' : ' ';
        result += `${linePrefix} ${currentLineNumber}: ${line}\n`;
      });
      
      return result;
    } catch (error) {
      console.error('파일 읽기 오류:', error);
      return `// 파일 읽기 실패: ${filePath}\n// 오류: ${error.message}`;
    }
  }

  // 가상 코드 생성 함수 (기존 코드 대체)
  function generateMockFileContent(filePath, lineNumber) {
    const fileName = filePath.split(/[\\/]/).pop();
    const isNexacroFile = filePath.includes('nexacro') || filePath.includes('.xfdl.js');
    
    let content = `// 가상 코드 (파일 접근 불가): ${filePath}\n\n`;
          
          if (isNexacroFile) {
      content += `/***********************************************************************\n`;
      content += ` * ${fileName.includes('xfdl.js') ? "Form 코드" : "Library 함수"}\n`;
      content += ` ***********************************************************************/\n\n`;
      content += `// 함수 정의 (라인 ${lineNumber} 부근)\n`;
      content += `${fileName.includes('xfdl.js') ? "this." : ""}${filePath.includes("fn_") ? "fn_" : ""}${filePath.includes("transaction") ? "transaction" : "함수명"} = function(${fileName.includes('transaction') ? "id, url, inData, outData, args, callback" : "arg1, arg2"})\n`;
      content += `{\n`;
      content += `    // 변수 선언\n`;
      content += `    var ${fileName.includes('xfdl.js') ? "objApp = nexacro.getApplication();" : "result = null;"}\n\n`;
      content += `    // 주요 로직 실행\n`;
      content += `    // 라인 ${lineNumber}에서 호출\n`;
      content += `    ${fileName.includes('transaction') ? "this.transaction(id, url, inData, outData, args, callback);" : "return result;"}\n`;
      content += `}\n`;
          } else {
      content += `// ${fileName}\n`;
      content += `function 함수명() {\n`;
      content += `  // 라인 ${lineNumber}에서 호출\n`;
      content += `  const result = someOperation();\n`;
      content += `  return result;\n`;
      content += `}\n`;
    }
    
    return content;
  }

  // 그 다음으로 실제 원격 소스코드를 읽는 기능을 구현합니다
  async function loadRemoteSourceCode(url, lineNumber, functionNameToFind = null, loadFullSource = false) {
    console.log(`원격 소스코드 로딩 시도: ${url}, 라인: ${lineNumber}${functionNameToFind ? ', 찾을 함수: ' + functionNameToFind : ''}${loadFullSource ? ', 전체 소스코드 로드' : ''}`);
    
    try {
      // CORS 우회를 위한 프록시 URL 사용 (개발/테스트 목적)
      // 실제 운영 환경에서는 서버 측 프록시 필요
      const corsProxies = [
        `https://cors-anywhere.herokuapp.com/${url}`,
        `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
        `https://corsproxy.io/?${encodeURIComponent(url)}`
      ];
      
      let sourceCode = null;
      let sourceMap = null;
      let error = null;
      
      // 여러 CORS 프록시 시도
      for (const proxyUrl of corsProxies) {
        try {
          const response = await fetch(proxyUrl, {
            method: 'GET',
            headers: {
              'X-Requested-With': 'XMLHttpRequest'
            },
            mode: 'cors',
            cache: 'no-cache'
          });
          
          if (response.ok) {
            sourceCode = await response.text();
            console.log(`소스코드 로딩 성공 (${proxyUrl.substring(0, 30)}...)`);
            break;
          }
        } catch (fetchError) {
          error = fetchError;
          console.warn(`프록시 ${proxyUrl.substring(0, 30)}... 사용 시도 실패:`, fetchError);
        }
      }
      
      // 모든 프록시 시도 실패 시 직접 요청 시도
      if (!sourceCode) {
        try {
          const directResponse = await fetch(url);
          if (directResponse.ok) {
            sourceCode = await directResponse.text();
            console.log('직접 URL 요청으로 소스코드 로딩 성공');
          }
        } catch (directError) {
          console.warn('직접 URL 요청 실패:', directError);
        }
      }
      
      // 소스코드를 가져올 수 없는 경우 가상 코드 생성
      if (!sourceCode) {
        console.warn('원격 소스코드 로딩 실패, 가상 코드 생성');
        return generateMockFileContent(url, lineNumber);
      }
      
      // 소스맵 확인 및 로드 시도
      try {
        const sourceMapRegex = /\/\/[#@]\s*sourceMappingURL=([^\s]+)/;
        const sourceMapMatch = sourceCode.match(sourceMapRegex);
        
        if (sourceMapMatch && sourceMapMatch[1]) {
          let sourceMapUrl = sourceMapMatch[1];
          
          // 상대 경로인 경우 URL 기준으로 절대 경로 생성
          if (!sourceMapUrl.startsWith('http')) {
            const urlObj = new URL(url);
            const pathParts = urlObj.pathname.split('/');
            pathParts.pop(); // 현재 파일 이름 제거
            const basePath = `${urlObj.origin}${pathParts.join('/')}`;
            sourceMapUrl = `${basePath}/${sourceMapUrl}`;
          }
          
          console.log(`소스맵 로드 시도: ${sourceMapUrl}`);
          
          // 소스맵 로드 시도
          for (const proxy of corsProxies) {
            try {
              const proxyMapUrl = proxy.replace(url, sourceMapUrl);
              const mapResponse = await fetch(proxyMapUrl);
              if (mapResponse.ok) {
                const mapData = await mapResponse.json();
                sourceMap = mapData;
                console.log('소스맵 로드 성공');
                break;
              }
            } catch (mapError) {
              console.warn('소스맵 로드 실패:', mapError);
            }
          }
        }
      } catch (mapError) {
        console.warn('소스맵 처리 중 오류:', mapError);
      }
      
      // 소스맵이 있는 경우 원본 소스 매핑 시도
      if (sourceMap && sourceMap.sourcesContent && sourceMap.sourcesContent.length > 0) {
        const originalSource = sourceMap.sourcesContent[0];
        if (originalSource) {
          sourceCode = originalSource;
          console.log('소스맵을 통한 원본 소스 복원 성공');
        }
      }
      
      // 난독화 코드 감지
      const isMinified = detectMinifiedCode(sourceCode);
      console.log(`코드 난독화 감지: ${isMinified ? '난독화됨' : '일반 코드'}`);
      
      // 코드 서식 처리 (난독화된 경우에만)
      let formattedCode = sourceCode;
      if (isMinified) {
        try {
          formattedCode = prettyPrintCode(sourceCode);
          console.log('코드 서식 적용 완료');
        } catch (formatError) {
          console.warn('코드 서식 적용 실패:', formatError);
          formattedCode = sourceCode; // 실패시 원본 사용
        }
      }
      
      // 소스맵이 있는 경우 원본 소스 매핑 시도
      if (sourceMap && sourceMap.sourcesContent && sourceMap.sourcesContent.length > 0) {
        const originalSource = sourceMap.sourcesContent[0];
        if (originalSource) {
          formattedCode = originalSource;
          console.log('소스맵을 통한 원본 소스 복원 성공');
        }
      }
      
      // 소스코드에서 라인 추출
      const lines = formattedCode.split('\n');
      
      // 라인 번호 유효성 검사
      if (lineNumber <= 0 || lineNumber > lines.length) {
        console.warn(`유효하지 않은 라인 번호: ${lineNumber}, 전체 라인 수: ${lines.length}`);
        lineNumber = Math.min(Math.max(1, lineNumber), lines.length);
      }
      
      // 먼저 함수 이름으로 직접 검색 (파라미터로 전달된 경우)
      let functionName = functionNameToFind;
      let targetLine = lineNumber - 1; // 0-based index
      let functionStartLine = targetLine;
      let functionEndLine = targetLine;
      let functionFound = false;
      
      // 1단계: 함수 이름이 직접 제공되었으면 해당 함수 찾기
      if (functionName) {
        console.log(`함수 이름으로 직접 검색: ${functionName}`);
        
        // 특수한 함수 패턴 처리 (this.함수명, 네임스페이스.함수명 등)
        const specialPatterns = [
          new RegExp(`this\\.${functionName}\\s*=\\s*function`, 'i'),
          new RegExp(`this\\.${functionName}\\s*=\\s*\\(.*?\\)\\s*=>`, 'i'),
          new RegExp(`function\\s+${functionName}\\s*\\(`, 'i'),
          new RegExp(`${functionName}\\s*:\\s*function`, 'i'),
          new RegExp(`var\\s+${functionName}\\s*=\\s*function`, 'i'),
          new RegExp(`let\\s+${functionName}\\s*=\\s*function`, 'i'),
          new RegExp(`const\\s+${functionName}\\s*=\\s*function`, 'i')
        ];
        
        // 특수 패턴으로 전체 코드 검색
        for (const pattern of specialPatterns) {
          const match = formattedCode.match(pattern);
          if (match) {
            // 찾은 위치 계산
            const matchPosition = match.index;
            const beforeText = formattedCode.substring(0, matchPosition);
            const lineCount = (beforeText.match(/\n/g) || []).length;
            
            functionStartLine = lineCount;
            functionFound = true;
            console.log(`함수 ${functionName} 패턴 발견: 라인 ${functionStartLine+1}`);
            break;
          }
        }
        
        // 축약된 이름으로도 검색 (난독화된 경우)
        if (!functionFound && functionName.includes('.')) {
          const shortName = functionName.split('.').pop();
          console.log(`축약된 이름으로 검색: ${shortName}`);
          
          for (let i = 0; i < lines.length; i++) {
            if (lines[i].includes(shortName) && 
                (lines[i].includes('function') || lines[i].includes('=>'))) {
              functionStartLine = i;
              functionFound = true;
              console.log(`함수 ${shortName}(축약 이름) 발견: 라인 ${functionStartLine+1}`);
              break;
            }
          }
        }
      }
      
      // 1.5단계: 타겟 라인에서 함수 이름 추출 시도 (함수 이름이 없거나 찾지 못한 경우)
      if (!functionFound) {
        // 타겟 라인 주변 컨텍스트 가져오기
        let contextLines = lines.slice(Math.max(0, targetLine - 20), Math.min(lines.length, targetLine + 20));
        let contextText = contextLines.join('\n');
        
        // 함수 이름 패턴 찾기
        const functionNamePatterns = [
          /(?:function|class)\s+(\w+[\w.]*)/i, // function foo
          /(\w+[\w.]*)\s*=\s*function/i, // foo = function
          /(\w+[\w.]*)\s*:\s*function/i, // foo: function
          /(\w+[\w.]*)\s*=\s*\(.*?\)\s*=>/i, // foo = () =>
          /(?:var|let|const)\s+(\w+[\w.]*)\s*=\s*function/i, // var foo = function
          /(?:var|let|const)\s+(\w+[\w.]*)\s*=\s*\(.*?\)\s*=>/i, // var foo = () =>
          /this\.(\w+[\w.]*)\s*=\s*function/i, // this.foo = function
          /this\.(\w+[\w.]*)\s*=\s*\(.*?\)\s*=>/i // this.foo = () =>
        ];
        
        // 현재 라인과 주변 컨텍스트에서 함수 이름 추출 시도
        for (const pattern of functionNamePatterns) {
          const matches = contextText.match(pattern);
          if (matches && matches[1]) {
            functionName = matches[1].trim();
            console.log(`함수 이름 추출: ${functionName}`);
            break;
          }
        }
        
        // 특별한 패턴: nexacro.__functionName 스타일
        const specialPatterns = [
          /(nexacro(?:\.\w+)+)\s*=\s*function/i,
          /(this(?:\.\w+)+)\s*=\s*function/i
        ];
        
        for (const pattern of specialPatterns) {
          const matches = contextText.match(pattern);
          if (matches && matches[1]) {
            functionName = matches[1].trim();
            console.log(`특수 함수 이름 발견: ${functionName}`);
            break;
          }
        }
        
        // 2단계: 함수 이름이 추출되면 해당 함수 전체를 찾기
        if (functionName) {
          // 전체 소스코드에서 함수 이름으로 검색
          const escapedFunctionName = functionName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          const functionRegexPattern = `(^|\\s|[,:=({])${escapedFunctionName}\\s*(?:=\\s*function|\\s*:\\s*function|\\s*=\\s*\\(.*?\\)\\s*=>|\\([^)]*\\)\\s*{)`;
          
          try {
            const functionRegex = new RegExp(functionRegexPattern, 'gm');
            let match;
            let bestMatchLine = -1;
            let bestMatchDistance = Number.MAX_SAFE_INTEGER;
            
            // 정규식으로 모든 일치 항목 찾기
            while ((match = functionRegex.exec(formattedCode)) !== null) {
              // 일치하는 라인 번호 찾기
              const matchPosition = match.index;
              const beforeText = formattedCode.substring(0, matchPosition);
              const lineCount = (beforeText.match(/\n/g) || []).length;
              
              // 타겟 라인에 가장 가까운 일치 항목 선택
              const distance = Math.abs(lineCount - targetLine);
              if (distance < bestMatchDistance) {
                bestMatchDistance = distance;
                bestMatchLine = lineCount;
              }
            }
            
            // 일치하는 라인을 찾았으면 함수 시작점으로 설정
            if (bestMatchLine !== -1) {
              functionStartLine = bestMatchLine;
              functionFound = true;
              console.log(`함수 ${functionName}의 시작점 발견: 라인 ${functionStartLine+1}`);
            }
          } catch (regexError) {
            console.warn(`함수 이름 검색 오류: ${regexError.message}`);
          }
        }
      }
      
      // 3단계: 함수 이름으로 찾지 못했을 경우 패턴 기반 검색
      if (!functionFound) {
        // 함수 전체 범위 찾기 - 넓은 범위로 검색
        const initialSearchRange = 100; // 기존 50에서 100으로 증가
        const maxSearchRange = 1000;   // 최대 1000라인까지 검색 가능하도록 설정
        
        let startLineIndex = Math.max(0, lineNumber - initialSearchRange);
        let endLineIndex = Math.min(lines.length - 1, lineNumber + initialSearchRange);
        
        // 동적 범위 확장을 위한 반복문
        for (let searchRange = initialSearchRange; searchRange <= maxSearchRange; searchRange *= 2) {
          startLineIndex = Math.max(0, lineNumber - searchRange);
          endLineIndex = Math.min(lines.length - 1, lineNumber + searchRange);
          
          // 함수 시작 부분 찾기 (다양한 패턴 검색)
          for (let i = lineNumber - 1; i >= startLineIndex; i--) {
            const line = lines[i].trim();
            
            // 더 많은 함수 시작 패턴을 확인
            const functionPatterns = [
              /function\s+\w+/, // function name()
              /function\s*\(/, // function()
              /\w+\s*=\s*function/, // name = function
              /\w+\s*:\s*function/, // name: function
              /\(\s*\)\s*=>/, // () =>
              /\w+\s*\([^)]*\)\s*{/, // name() {
              /class\s+\w+/, // class Name
              /export\s+(default\s+)?(function|class)/, // export function/class
              /[{,]\s*\w+\s*\([^)]*\)\s*{/, // method() {
              /this\.\w+\s*=\s*function/ // this.method = function
            ];
            
            // 패턴 검사
            const isFunction = functionPatterns.some(pattern => pattern.test(line));
            
            if (isFunction || 
                line.includes('function ') || 
                line.includes('async function ') ||
                line.includes('=> {') || 
                line.includes('= function')) {
              functionStartLine = i;
              functionFound = true;
              break;
            }
          }
          
          if (functionFound) break;
          
          // 검색 범위를 넓혀도 함수 시작을 찾지 못하면 계속 확장
          console.log(`함수 시작을 찾지 못함, 검색 범위 확장: ${searchRange} -> ${searchRange * 2}`);
        }
        
        // 그래도 함수를 찾지 못한 경우, 난독화된 코드로 가정하고 전체 파일 확인
        if (!functionFound && isMinified) {
          console.log("난독화된 코드에서 함수를 찾지 못했습니다. 파일 전체를 탐색합니다.");
          // 라인 1부터 전체 파일을 보여줌
          functionStartLine = 0;
          functionFound = true;
        } else if (!functionFound) {
          // 일반 코드에서 함수를 찾지 못한 경우, 기본 범위 사용
          functionStartLine = Math.max(0, lineNumber - 50);
          console.log(`함수 시작을 식별할 수 없어 라인 ${functionStartLine+1}부터 보여줍니다.`);
        }
      }
      
      // 4단계: 함수 끝 부분 찾기 (중괄호 균형 고려)
      let braceCount = 0;
      let foundStartBrace = false;
      
      // 함수 시작 줄부터 시작하여 함수 끝 찾기
      for (let i = functionStartLine; i < lines.length && i <= functionStartLine + 2000; i++) {
        const line = lines[i].trim();
        
        // 중괄호 계산
        if (line.includes('{')) {
          foundStartBrace = true;
          braceCount += (line.match(/{/g) || []).length;
        }
        
        if (line.includes('}')) {
          braceCount -= (line.match(/}/g) || []).length;
        }
        
        // 함수 끝 조건: 중괄호 균형이 맞고, 함수 시작 이후
        if (foundStartBrace && braceCount <= 0 && i > functionStartLine) {
          functionEndLine = i;
          break;
        }
      }
      
      // 난독화된 코드에서 함수 끝을 찾지 못한 경우
      if (isMinified && (functionEndLine === functionStartLine || braceCount > 0)) {
        // 난독화된 코드는 전체 파일을 보여줌
        functionEndLine = lines.length - 1;
        console.log(`난독화된 코드에서 함수 끝을 찾지 못해 파일 전체를 보여줍니다.`);
      }
      // 일반 함수가 너무 긴 경우 제한
      else if (functionEndLine - functionStartLine > 1000 || functionEndLine === functionStartLine) {
        functionEndLine = Math.min(lines.length - 1, functionStartLine + 500);
        console.warn(`함수가 너무 길거나 끝을 찾지 못해 ${functionEndLine - functionStartLine + 1}라인으로 제한합니다.`);
      }
      
      // 5단계: 함수 코드 추출 및 서식화
      const extractedLines = lines.slice(functionStartLine, functionEndLine + 1);
      const extractedCode = extractedLines.join('\n');
      
      // 추출된 코드 서식 개선
      const finalFormattedCode = prettyPrintCode(extractedCode);
      const formattedLines = finalFormattedCode.split('\n');
      
      // 6단계: 결과 구성
      let targetLineName = functionName ? `함수: ${functionName}` : `라인: ${lineNumber}`;
      let result = `// ${url} (${targetLineName}, 라인 ${functionStartLine+1}-${functionEndLine+1})\n\n`;
      
      // 서식이 적용된 코드를 라인 번호와 함께 결과에 추가
      for (let i = 0; i < formattedLines.length; i++) {
        const line = formattedLines[i];
        
        // 원본과 서식 적용 후 코드 라인의 비율을 고려한 라인 번호 계산
        const originalLineNumber = functionStartLine + 1 + Math.floor(i * extractedLines.length / formattedLines.length);
        const isTargetLine = originalLineNumber === lineNumber;
        const prefix = isTargetLine ? '>' : ' '; // 호출 라인 강조
        result += `${prefix} ${originalLineNumber.toString().padStart(4, ' ')}: ${line}\n`;
      }
      
      return result;
      } catch (error) {
      console.error('원격 소스코드 로딩 중 오류:', error);
      return `// ${url} 로딩 실패\n// 오류: ${error.message}\n\n${generateMockFileContent(url, lineNumber)}`;
    }
  }
  
  // 난독화된 코드 감지 함수
  function detectMinifiedCode(code) {
    if (!code) return false;
    
    // 난독화 코드의 특징 확인:
    // 1. 긴 라인 (일반적으로 500자 이상)
    // 2. 세미콜론 빈도
    // 3. 짧은 변수명 (한 글자 변수)
    
    const lines = code.split('\n');
    
    // 평균 라인 길이 계산
    const totalLength = lines.reduce((sum, line) => sum + line.length, 0);
    const avgLineLength = totalLength / lines.length;
    
    // 짧은 변수 이름 패턴 (a, b, c, i, j, x, y 등)
    const shortVarPattern = /\b[a-z]{1,2}\b/g;
    const shortVarMatches = code.match(shortVarPattern) || [];
    
    // 세미콜론 빈도 계산
    const semicolons = (code.match(/;/g) || []).length;
    const semicolonDensity = semicolons / totalLength;
    
    // 난독화 판단
    return (
      avgLineLength > 100 || // 라인당 평균 100자 이상
      (shortVarMatches.length / lines.length > 5) || // 라인당 짧은 변수 5개 이상
      semicolonDensity > 0.02 // 총 코드 길이 대비 세미콜론 비율 2% 이상
    );
  }
  
  // 코드 서식 개선 함수
  function prettyPrintCode(code) {
    try {
      // 기본적인 서식 규칙 적용
      let formatted = code;
      
      // 중괄호 사이에 줄바꿈 추가
      formatted = formatted.replace(/({)(?!\n)/g, '$1\n');
      formatted = formatted.replace(/(?<!\n)(})/g, '\n$1');
      
      // 세미콜론 뒤에 줄바꿈 추가 (여러 명령이 한 줄에 있는 경우)
      formatted = formatted.replace(/;(?!\n| \n)/g, ';\n');
      
      // 들여쓰기 조정
      let indentLevel = 0;
      const formattedLines = [];
      const lines = formatted.split(/[\r\n]+/);
      
      for (let line of lines) {
        const trimmedLine = line.trim();
        if (!trimmedLine) continue;
        
        // 닫는 괄호로 시작하면 들여쓰기 감소
        if (trimmedLine.startsWith('}') || trimmedLine.startsWith(')')) {
          indentLevel = Math.max(0, indentLevel - 1);
        }
        
        // 현재 들여쓰기 수준에 맞게 라인 추가
        const indent = '  '.repeat(indentLevel);
        formattedLines.push(indent + trimmedLine);
        
        // 여는 괄호로 끝나면 들여쓰기 증가
        if (trimmedLine.endsWith('{')) {
          indentLevel++;
        }
        
        // 한 라인에 닫는 괄호와 여는 괄호가 모두 있으면 들여쓰기 유지
        const openBraces = (trimmedLine.match(/{/g) || []).length;
        const closeBraces = (trimmedLine.match(/}/g) || []).length;
        
        if (openBraces > 0 && closeBraces > 0 && openBraces === closeBraces) {
          // 들여쓰기 유지
        } else if (closeBraces > openBraces) {
          // 닫는 괄호가 더 많으면 들여쓰기 감소
          indentLevel = Math.max(0, indentLevel - (closeBraces - openBraces));
        }
      }
      
      // 연산자 주변에 공백 추가
      formatted = formattedLines.join('\n');
      formatted = formatted.replace(/([=+\-*/%&|^!<>]+)(?=\w)/g, '$1 ');
      formatted = formatted.replace(/(\w)(?=[=+\-*/%&|^!<>]+)/g, '$1 ');
      
      // 세미콜론 뒤에 공백 추가
      formatted = formatted.replace(/;([^\s\n])/g, '; $1');
      
      // 콤마 뒤에 공백 추가
      formatted = formatted.replace(/,([^\s\n])/g, ', $1');
      
      return formatted;
    } catch (error) {
      console.warn('코드 서식 적용 중 오류:', error);
      return code; // 에러 발생 시 원본 코드 반환
    }
  }

  // 다이어그램 노드에 클릭 이벤트 추가하는 함수
  function setupNodeClickEvents(svgElement, frames) {
    try {
      if (!frames || frames.length === 0) {
        console.warn('프레임 정보가 없습니다.');
        return;
      }
      
      console.log('스택 프레임 정보:', frames);
      
      // 다이어그램 타입 감지 (플로우차트, 시퀀스 다이어그램 등)
      let diagramType = 'flowchart';
      if (svgElement.querySelector('.actor') || svgElement.querySelector('.messageText')) {
        diagramType = 'sequence';
      }
      
      console.log(`다이어그램 타입: ${diagramType}`);
      
      // 노드 요소 선택 (플로우차트와 시퀀스 다이어그램 모두 지원)
      const nodeElements = svgElement.querySelectorAll('.node, .actor, .note, g[id^="flowchart-"], g[id^="node"], g.node, rect, polygon, circle, ellipse');
      
      if (nodeElements.length === 0) {
        console.log('클릭 가능한 노드를 찾을 수 없습니다.');
        return;
      }
      
      // 프레임 정보 맵 구성 (정확한 매핑을 위해)
      const frameMap = {};
      frames.forEach((frame, idx) => {
        const key = frame.functionName.toLowerCase();
        const fileKey = frame.fileName.toLowerCase();
        
        // 함수명, 파일명, 인덱스 기준으로 프레임 저장
        frameMap[key] = frame;
        frameMap[fileKey] = frame;
        frameMap[idx] = frame;
        frameMap[`${key}@${fileKey}`] = frame;
        
        // 함수명에서 특수 접두사 제거한 버전도 저장 (예: fn_ 접두사)
        if (key.startsWith('fn_')) {
          frameMap[key.substring(3)] = frame;
        }
      });
      
      console.log(`${nodeElements.length}개의 노드에 클릭 이벤트 추가, ${frames.length}개의 프레임 사용 가능`);
      
      // 시퀀스 다이어그램인 경우 노드-프레임 매핑 순서 조정 (상단부터 순서대로)
      let nodeFrameMapping = [];
      
      if (diagramType === 'sequence') {
        // 시퀀스 다이어그램의 경우 순서대로 매핑
        nodeElements.forEach((node, idx) => {
          if (idx < frames.length) {
            nodeFrameMapping.push({
              node: node,
              frame: frames[idx]
            });
          }
        });
      } else {
        // 플로우차트의 경우 노드 내용과 프레임 내용 비교하여 매핑
        nodeElements.forEach((node) => {
          // 노드에서 텍스트 추출
          const nodeTextContent = extractNodeText(node);
          console.log(`노드 텍스트: "${nodeTextContent}"`);
          
          // 가장 적합한 프레임 찾기
          const matchedFrame = findMatchingFrame(nodeTextContent, frameMap, frames);
          
          if (matchedFrame) {
            nodeFrameMapping.push({
              node: node,
              frame: matchedFrame,
              text: nodeTextContent
            });
          }
        });
      }
      
      console.log('노드-프레임 매핑 결과:', nodeFrameMapping);
      
      // 각 노드에 클릭 이벤트 추가
      nodeFrameMapping.forEach((mapping, index) => {
        const { node, frame, text } = mapping;
        
        // 노드 스타일 변경하여 클릭 가능함을 표시
        node.style.cursor = 'pointer';
        
        // 툴팁 설정 - 정확한 파일 경로와 라인 번호 표시
        if (frame) {
          node.setAttribute('title', `${frame.functionName}\n${frame.filePath}:${frame.lineNumber}\n클릭하여 소스 열기`);
          console.log(`노드 ${index}에 매핑된 프레임:`, frame.filePath, frame.lineNumber);
        } else {
          node.setAttribute('title', '소스 정보 없음');
        }

        // 마우스 오버 효과 추가
        node.addEventListener('mouseenter', function() {
          this.style.filter = 'brightness(1.2)';
          if (this.tagName.toLowerCase() === 'rect' || this.tagName.toLowerCase() === 'polygon') {
            this.style.stroke = '#4285F4';
            this.style.strokeWidth = '2px';
          }
        });
        
        node.addEventListener('mouseleave', function() {
          this.style.filter = '';
          if (this.tagName.toLowerCase() === 'rect' || this.tagName.toLowerCase() === 'polygon') {
            this.style.stroke = '';
            this.style.strokeWidth = '';
          }
        });
        
        // 클릭 이벤트 리스너 추가
        node.addEventListener('click', function(event) {
          event.stopPropagation(); // 이벤트 버블링 방지
          
          if (frame && frame.filePath) {
            // 정확한 경로와 라인 번호 기록
            console.log(`노드 클릭: "${text || ''}"\n파일: ${frame.filePath}\n라인: ${frame.lineNumber}`);
            navigateToSource(frame.filePath, frame.lineNumber);
          } else {
            console.warn('이 노드에 연결된 소스 정보가 없습니다.');
          }
        });
            });
        } catch (error) {
      console.error('노드 클릭 이벤트 설정 오류:', error);
    }
  }
  
  // 노드에서 텍스트 내용 추출
  function extractNodeText(node) {
    let nodeText = '';
    
    // SVG 텍스트 요소 찾기
    const textElements = node.querySelectorAll('text');
    if (textElements.length > 0) {
      // 모든 텍스트 요소의 내용 결합
      textElements.forEach(textEl => {
        if (textEl.textContent) {
          nodeText += textEl.textContent.trim() + ' ';
        }
      });
    } else {
      // 텍스트 요소가 없으면 title 또는 id 속성 사용
      nodeText = node.getAttribute('title') || node.getAttribute('id') || '';
    }
    
    return nodeText.trim();
  }
  
  // 노드 텍스트와 가장 일치하는 프레임 찾기
  function findMatchingFrame(nodeText, frameMap, frames) {
    if (!nodeText) return null;
    
    // 1. 직접 매칭 시도
    const lowerText = nodeText.toLowerCase();
    if (frameMap[lowerText]) {
      return frameMap[lowerText];
    }
    
    // 2. 노드 텍스트에서 함수명 또는 파일명 추출
    const parts = nodeText.split(/[\s()@:]/); // 공백, 괄호, @, : 기호로 분리
    
    for (const part of parts) {
      const trimmedPart = part.trim().toLowerCase();
      if (trimmedPart && frameMap[trimmedPart]) {
        // 텍스트 일부와 일치하는 프레임 발견
        return frameMap[trimmedPart];
      }
    }
    
    // 3. 함수명이나 파일명의 일부가 포함된 프레임 검색
    let bestMatch = null;
    let bestScore = 0;
    
    frames.forEach(frame => {
      let score = 0;
      
      // 함수명 일치 점수
      if (lowerText.includes(frame.functionName.toLowerCase())) {
        score += 2;
      }
      
      // 파일명 일치 점수
      if (frame.fileName && lowerText.includes(frame.fileName.toLowerCase())) {
        score += 3;
      }
      
      // @ 기호 포함 시 넥사크로 스타일 스택 트레이스로 가정
      if (lowerText.includes('@') && frame.filePath) {
        const urlParts = frame.filePath.toLowerCase().split('/');
        for (const part of urlParts) {
          if (part && lowerText.includes(part)) {
            score += 1;
          }
        }
      }
      
      if (score > bestScore) {
        bestScore = score;
        bestMatch = frame;
      }
    });
    
    // 최소 점수 이상인 경우만 반환
    return bestScore >= 1 ? bestMatch : null;
  }

  // 스택 트레이스에서 파일 경로와 라인 번호 추출
  function parseStackTraceLine(stackLine) {
    // 정규식으로 URL과 라인 번호 추출: "함수명 @ URL:라인번호"
    const regex = /(?:.*@\s*)?(https?:\/\/[^:]+)(:\d+)?/;
    const match = stackLine.match(regex);
    
    if (match) {
      const url = match[1];
      // 라인 번호가 있으면 추출, 없으면 1로 설정
      const lineNumber = match[2] ? parseInt(match[2].substring(1)) : 1;
      return { filePath: url, lineNumber: lineNumber };
    }
    
    return null;
  }

  // Sources 탭으로 이동하는 함수
  function navigateToSource(filePath, lineNumber) {
    console.log(`Sources 탭으로 이동 시도: ${filePath}:${lineNumber}`);
    
    try {
      // URL에서 라인 번호 추출 (URL 형식이 "파일경로:라인번호"인 경우)
      let parsedLineNumber = lineNumber;
      const lineMatch = filePath.match(/:(\d+)$/);
      if (lineMatch) {
        parsedLineNumber = parseInt(lineMatch[1]);
        filePath = filePath.replace(/:(\d+)$/, '');
        console.log(`URL에서 라인 번호 추출: ${parsedLineNumber}, 수정된 경로: ${filePath}`);
      }
      
      // 파일 경로에서 파일명만 추출 (쿼리 파라미터 제외)
      const fileUrl = new URL(filePath, window.location.origin);
      const fileName = fileUrl.pathname.split('/').pop().split('?')[0];
      const filePathNoQuery = filePath.split('?')[0];
      
      // 파일 경로의 마지막 두 부분 추출 (path/to/file.js -> to/file.js)
      const pathParts = fileUrl.pathname.split('/');
      const fileNameWithParent = pathParts.length > 1 
        ? pathParts.slice(-2).join('/') 
        : fileName;
      
      // 파일 경로의 마지막 세 부분 추출 (path/to/file.js -> path/to/file.js)
      const fileNameWithGrandParent = pathParts.length > 2
        ? pathParts.slice(-3).join('/')
        : fileNameWithParent;
      
      console.log(`파일명: ${fileName}, 쿼리 없는 경로: ${filePathNoQuery}`);
      console.log(`부모 경로 포함 파일명: ${fileNameWithParent}`);
      console.log(`상위 경로 포함 파일명: ${fileNameWithGrandParent}`);
      console.log(`라인 번호: ${parsedLineNumber}`);
      
      // 넥사크로 파일 여부 확인
      const isNexacroFile = fileName.includes('.xfdl.js');
      console.log(`넥사크로 파일 여부: ${isNexacroFile}`);
      
      // Chrome DevTools API를 통한 직접 접근 시도
      if (typeof chrome !== 'undefined' && chrome.devtools && chrome.devtools.inspectedWindow) {
        // 소스 탭에서 해당 파일 찾아서 이동하는 스크립트
        const openFileScript = `
          (function() {
            try {
              const targetUrl = "${filePath}";
              const targetFile = "${fileName}";
              const targetFileWithParent = "${fileNameWithParent}";
              const targetFileWithGrandParent = "${fileNameWithGrandParent}";
              const filePathNoQuery = "${filePathNoQuery}";
              const isNexacroFile = ${isNexacroFile};
              const lineNum = ${parsedLineNumber};
              let foundFile = false;
              
              // 콘솔 로그 스타일 설정
              const styles = {
                info: "color: blue; font-weight: bold",
                success: "color: green; font-weight: bold",
                error: "color: red; font-weight: bold",
                warning: "color: orange; font-weight: bold",
                special: "color: purple; font-weight: bold"
              };
              
              console.log("%c소스 파일 찾기 시작: " + targetUrl + ":" + lineNum, styles.info);
              
              // 도메인 이름 추출 (URL 비교용)
              function extractDomain(url) {
                try {
                  const parsed = new URL(url);
                  return parsed.hostname;
                } catch(e) {
                  return null;
                }
              }
              
              // URL 비교 함수 - 쿼리 파라미터 제외하고 정규화
              function compareUrls(url1, url2) {
                if (!url1 || !url2) return false;
                
                try {
                  // 쿼리 파라미터 제거
                  const cleanUrl1 = url1.split('?')[0];
                  const cleanUrl2 = url2.split('?')[0];
                  
                  // 완전 일치
                  if (cleanUrl1 === cleanUrl2) return true;
                  
                  // 파일 경로 비교
                  const path1 = cleanUrl1.split('/').filter(p => p).join('/');
                  const path2 = cleanUrl2.split('/').filter(p => p).join('/');
                  
                  // 경로 마지막 부분 비교 (파일명)
                  const fileName1 = path1.split('/').pop();
                  const fileName2 = path2.split('/').pop();
                  
                  // 파일명 일치
                  if (fileName1 === fileName2) return true;
                  
                  return false;
                } catch(e) {
                  console.log("%cURL 비교 오류: " + e.message, styles.error);
                  return false;
                }
              }
              
              // URL 유사도 체크
              function urlSimilarity(url1, url2) {
                if (!url1 || !url2) return 0;
                
                try {
                  // 정규화 - 쿼리 제거, 소문자로 변환
                  const norm1 = url1.split('?')[0].toLowerCase();
                  const norm2 = url2.split('?')[0].toLowerCase();
                  
                  // 완전 일치
                  if (norm1 === norm2) return 1.0;
                  
                  // 파일명 추출
                  const file1 = norm1.split('/').pop();
                  const file2 = norm2.split('/').pop();
                  
                  // 파일명 일치
                  if (file1 === file2) return 0.8;
                  
                  // 경로의 일부가 포함되어 있는 경우
                  if (norm1.includes(file2) || norm2.includes(file1)) return 0.6;
                  
                  // 경로 일부 매칭
                  let score = 0;
                  const parts1 = norm1.split('/');
                  const parts2 = norm2.split('/');
                  
                  // 공통 경로 부분 찾기
                  const minLength = Math.min(parts1.length, parts2.length);
                  let commonParts = 0;
                  
                  for (let i = 0; i < minLength; i++) {
                    if (parts1[parts1.length - 1 - i] === parts2[parts2.length - 1 - i]) {
                      commonParts++;
                    }
                  }
                  
                  // 공통 경로가 있으면 유사도 점수 부여
                  if (commonParts > 0) {
                    score = 0.3 + (commonParts / minLength) * 0.3;
                  }
                  
                  return score;
                } catch(e) {
                  return 0;
                }
              }
              
              // 모든 UI 소스코드 URL 검사 함수
              function getAllUISourceCodeURLs() {
                const allURLs = new Set();
                
                // 1. Workspace API
                if (Workspace && Workspace.workspace) {
                  const projects = Workspace.workspace.projects();
                  for (const project of projects) {
                    const uiSourceCodes = project.uiSourceCodes();
                    for (const sourceCode of uiSourceCodes) {
                      allURLs.add(sourceCode.url());
                    }
                  }
                }
                
                // 2. Sources API
                if (Sources && Sources.workspace) {
                  const networkProject = Sources.workspace.project('network');
                  if (networkProject) {
                    networkProject.uiSourceCodes().forEach(sourceCode => {
                      allURLs.add(sourceCode.url());
                    });
                  }
                }
                
                // 3. UI SourceCode Frames
                if (Sources && Sources.sourcesView && Sources.sourcesView._uiSourceCodeFrames) {
                  Object.keys(Sources.sourcesView._uiSourceCodeFrames).forEach(url => {
                    allURLs.add(url);
                  });
                }
                
                // 4. 네트워크 요청에서 URL 가져오기
                if (Network && Network.networkLog) {
                  const requests = Network.networkLog.requests();
                  if (requests) {
                    requests.forEach(request => {
                      if (request && request.url && request.url().endsWith('.js')) {
                        allURLs.add(request.url());
                      }
                    });
                  }
                }
                
                return Array.from(allURLs);
              }
              
              // URL 내에 특정 파일명이 포함되어 있는지 확인하는 함수 (유연한 매칭)
              function isFileMatch(url, targetFileName) {
                if (!url || !targetFileName) return false;
                
                // URL 디코딩
                try {
                  const decodedUrl = decodeURIComponent(url);
                  
                  // 직접 일치
                  if (url.includes(targetFileName) || decodedUrl.includes(targetFileName)) {
                    return true;
                  }
                  
                  // 파일 확장자 앞부분만 추출
                  const baseName = targetFileName.split('.')[0];
                  
                  // 확장자만 제외하고 파일명 부분만 확인
                  if (url.includes(baseName) || decodedUrl.includes(baseName)) {
                    return true;
                  }
                  
                  return false;
                } catch(e) {
                  console.log("%cURL 디코딩 오류: " + e.message, styles.error);
                  return false;
                }
              }
              
              // 2. 정확한 URL로 이동 시도 - 라인 번호 직접 지정
              if (typeof UI !== 'undefined' && UI.panels && UI.panels.sources) {
                try {
                  // DevTools API를 통한 파일 열기 시도 (정확한 URL과 라인 번호 사용)
                  console.log("%c정확한 URL로 직접 이동 시도: " + targetUrl + ":" + lineNum, styles.info);
                  UI.panels.sources.showUISourceCode(targetUrl, lineNum - 1);
                  
                  // 쿼리 제거한 URL로도 시도
                  UI.panels.sources.showUISourceCode(filePathNoQuery, lineNum - 1);
                  console.log("%c정확한 URL로 이동 시도 완료", styles.success);
                } catch (err) {
                  console.log("%cUI.panels.sources.showUISourceCode 실패: " + err.message, styles.error);
                }
              }
              
              // 3. 모든 URL 확인 및 매칭
              const allURLs = getAllUISourceCodeURLs();
              console.log("%c사용 가능한 소스 파일 검색 (총 " + allURLs.length + "개 파일):", styles.info);
              
              // 유사도 기반 URL 매칭
              const urlScores = [];
              
              // 파일명 기반 정렬된 URL 리스트 생성
              allURLs.forEach(url => {
                // 대상 URL과 유사도 계산
                let score = 0;
                
                // 전체 URL 유사도
                score = Math.max(score, urlSimilarity(url, targetUrl));
                
                // 쿼리 없는 URL 유사도
                score = Math.max(score, urlSimilarity(url, filePathNoQuery));
                
                // 경로 매칭
                if (isFileMatch(url, targetFile)) {
                  score = Math.max(score, 0.7);
                }
                
                if (isFileMatch(url, targetFileWithParent)) {
                  score = Math.max(score, 0.8); 
                }
                
                if (isFileMatch(url, targetFileWithGrandParent)) {
                  score = Math.max(score, 0.9);
                }
                
                // 도메인 매칭
                const urlDomain = extractDomain(url);
                const targetDomain = extractDomain(targetUrl);
                
                if (urlDomain && targetDomain && urlDomain === targetDomain) {
                  score += 0.1; // 같은 도메인 보너스
                }
                
                // 넥사크로 파일 특수 처리
                if (isNexacroFile && url.includes('.xfdl.js')) {
                  score += 0.1;
                }
                
                // 스코어가 있는 경우만 추가
                if (score > 0) {
                  urlScores.push({ url, score });
                }
              });
              
              // 점수순으로 정렬
              urlScores.sort((a, b) => b.score - a.score);
              
              // 상위 5개 URL 로깅
              console.log("%c가장 유사한 URL (최대 5개):", styles.special);
              urlScores.slice(0, 5).forEach((item, index) => {
                console.log("%c#" + (index + 1) + " 점수: " + item.score.toFixed(2) + ", URL: " + item.url, 
                  item.score > 0.8 ? styles.success : "color: gray");
              });
              
              // 가장 유사한 URL로 이동 시도
              if (urlScores.length > 0) {
                foundFile = true;
                const bestMatch = urlScores[0];
                
                if (bestMatch.score > 0.7) {
                  console.log("%c가장 일치하는 URL로 이동 시도: " + bestMatch.url + ":" + lineNum, styles.success);
                  
                  try {
                    const uiSourceCode = Workspace.workspace.uiSourceCodeForURL(bestMatch.url);
                    if (uiSourceCode) {
                      Common.Revealer.reveal(uiSourceCode.uiLocation(lineNum - 1, 0));
                      return { method: "Common.Revealer.reveal", success: true, url: bestMatch.url };
                } else {
                      console.log("%c소스코드 객체를 가져올 수 없음: " + bestMatch.url, styles.error);
                    }
                  } catch (err) {
                    console.log("%c첫 번째 URL 열기 실패: " + err.message, styles.error);
                  }
                }
                
                // 상위 3개 URL 모두 시도
                for (let i = 1; i < Math.min(3, urlScores.length); i++) {
                  try {
                    const alternateUrl = urlScores[i].url;
                    console.log("%c대체 URL 시도 #" + i + ": " + alternateUrl + ":" + lineNum, styles.info);
                    
                    const uiSourceCode = Workspace.workspace.uiSourceCodeForURL(alternateUrl);
                    if (uiSourceCode) {
                      console.log("%cCommon.Revealer.reveal 사용 - 라인: " + lineNum, styles.success);
                      Common.Revealer.reveal(uiSourceCode.uiLocation(lineNum - 1, 0));
                      return { method: "Common.Revealer.reveal", success: true, url: alternateUrl };
                    }
                  } catch (innerErr) {
                    console.log("%c대체 URL #" + i + " 실패: " + innerErr.message, styles.error);
                  }
                }
                
                // 다른 방법으로 시도
                try {
                  // WebInspector API 직접 열기 시도
                  if (typeof WebInspector !== 'undefined' && WebInspector.NetworkPanel) {
                    console.log("%cWebInspector API 직접 열기 시도: " + bestMatch.url, styles.info);
                    WebInspector.NetworkPanel.openResource(bestMatch.url, lineNum - 1);
                    return { method: "WebInspector.NetworkPanel.openResource", success: true };
                  }
                } catch (err) {
                  console.log("%cWebInspector 직접 열기 실패: " + err.message, styles.error);
                }
              }
              
              // 파일을 찾지 못했을 경우
              if (!foundFile) {
                console.log("%c파일을 찾지 못했습니다: " + targetFile, styles.error);
                console.log("%c원본 URL: " + targetUrl, styles.error);
                console.log("%c라인 번호: " + lineNum, styles.error);
                
                // 디버거 중단점
                debugger;
              }
              
              return { success: foundFile, message: foundFile ? "파일 찾음" : "파일을 찾지 못함" };
            } catch(e) {
              console.error("소스 파일 검색 오류:", e);
              return { error: e.message };
            }
          })()
        `;
        
        // DevTools 스크립트 실행
        chrome.devtools.inspectedWindow.eval(openFileScript, function(result, exceptionInfo) {
          console.log('스크립트 실행 결과:', result, exceptionInfo);
          
          if (exceptionInfo || (result && result.error)) {
            console.error('소스 탐색 스크립트 실행 오류:', exceptionInfo || result.error);
            
            // 실패 시 기본 방법으로 시도
            fallbackSourcesNavigation(filePath, filePathNoQuery, fileName, parsedLineNumber);
          } else if (result && !result.success) {
            console.warn('파일을 찾지 못했습니다:', result.message);
            fallbackSourcesNavigation(filePath, filePathNoQuery, fileName, parsedLineNumber);
          } else {
            console.log('소스 탐색 성공:', result);
          }
        });
      } else {
        console.warn('Chrome DevTools API를 사용할 수 없습니다.');
        fallbackSourcesNavigation(filePath, filePathNoQuery, fileName, parsedLineNumber);
      }
    } catch (error) {
      console.error('Sources 패널 열기 오류:', error);
      showSourceNavigationGuide(filePath, lineNumber);
    }
  }
  
  // 대체 소스 탐색 방법 (여러 방법 시도)
  function fallbackSourcesNavigation(filePath, filePathNoQuery, fileName, lineNumber) {
    console.log('대체 소스 탐색 방법 시도...');
    
    // 1. 원래 경로로 시도 (정확한 라인 번호 사용)
    try {
      if (typeof chrome !== 'undefined' && chrome.devtools && chrome.devtools.panels && chrome.devtools.panels.openResource) {
        chrome.devtools.panels.openResource(filePath, lineNumber - 1, function(result) {
          if (chrome.runtime.lastError) {
            console.error('원본 경로 오류:', chrome.runtime.lastError);
            
            // 2. 쿼리 없는 경로로 시도
            chrome.devtools.panels.openResource(filePathNoQuery, lineNumber - 1, function(result) {
              if (chrome.runtime.lastError) {
                console.error('쿼리 없는 경로 오류:', chrome.runtime.lastError);
                
                // 3. 파일명만으로 시도
                const lastFallbackScript = `
                  (function() {
                    try {
                      // 파일 시스템에서 직접 검색 시도
                      const fileName = "${fileName}";
                      const lineNum = ${lineNumber};
                      console.log("%c마지막 시도로 파일 찾기: " + fileName + ":" + lineNum, "color: purple; font-weight: bold");
                      
                      // 수동 탐색 가이드 출력
                      console.log("%c수동 검색 방법:", "color: purple; font-weight: bold");
                      console.log("%c1. Ctrl+P를 눌러 파일 검색", "color: gray");
                      console.log("%c2. 파일명 입력: " + fileName, "color: gray");
                      console.log("%c3. 파일 선택 후 Ctrl+G로 라인 " + lineNum + "으로 이동", "color: gray");
                      
                      debugger;
                      return { message: "사용자 수동 탐색 필요" };
                    } catch(e) {
                      return { error: e.message };
                    }
                  })()
                `;
                
                chrome.devtools.inspectedWindow.eval(lastFallbackScript);
                showSourceNavigationGuide(filePath, lineNumber);
              } else {
                console.log('쿼리 없는 경로로 이동 성공');
              }
            });
          } else {
            console.log('원본 경로로 이동 성공');
          }
        });
      } else {
        showSourceNavigationGuide(filePath, lineNumber);
      }
      } catch (error) {
      console.error('대체 소스 탐색 오류:', error);
      showSourceNavigationGuide(filePath, lineNumber);
    }
  }

  // 소스 코드를 새 탭에서 열기 시도 (fallback)
  function openSourceCodeInNewTab(filePath, lineNumber) {
    try {
      // 사용자에게 소스 위치 안내
      showSourceNavigationGuide(filePath, lineNumber);
      
      // 새 탭에서 소스 코드 열기 시도 (대부분의 브라우저에서 CORS 제한으로 실패할 수 있음)
      const newTab = window.open(filePath, '_blank');
      if (newTab) {
        // 새 탭에서 라인으로 스크롤 시도
        newTab.addEventListener('load', function() {
          try {
            newTab.postMessage({
              type: 'scrollToLine',
              line: lineNumber
            }, '*');
          } catch (e) {
            console.error('새 탭에서 라인 이동 실패:', e);
          }
        });
      }
    } catch (e) {
      console.error('새 탭에서 소스 열기 실패:', e);
    }
  }

  // 소스 코드 네비게이션 가이드 표시
  function showSourceNavigationGuide(filePath, lineNumber) {
    alert(`소스 파일 위치: ${filePath}:${lineNumber}\n\nSources 패널에서 해당 파일을 열고 이 라인 번호로 이동하세요.`);
  }
}); 